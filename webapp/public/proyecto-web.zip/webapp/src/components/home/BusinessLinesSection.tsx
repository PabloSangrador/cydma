import { Link } from "react-router-dom";
import { Warehouse, Building2, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";

const businessLines = [
  {
    icon: Warehouse,
    title: "Almacén",
    description:
      "Stock en continua rotación con servicio piso a piso para toda España. Productos listos para montaje con atención comercial personalizada.",
    href: "/almacen",
    image: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80",
  },
  {
    icon: Building2,
    title: "Contract",
    description:
      "Obra nueva y rehabilitación con procesos estandarizados. Asesoramiento integral desde la concepción hasta el seguimiento a pie de obra.",
    href: "/contract",
    image: "https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=800&q=80",
  },
  {
    icon: Globe,
    title: "Export",
    description:
      "Proyectos internacionales con material etiquetado, embalado y paletizado. Protocolos de envío estandarizados para todo el mundo.",
    href: "/export",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80",
  },
];

export default function BusinessLinesSection() {
  return (
    <section className="py-24 bg-primary text-primary-foreground">
      <div className="container">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="text-accent-foreground/70 font-medium tracking-wider uppercase text-sm mb-2">
            Líneas de Negocio
          </p>
          <h2 className="font-serif text-display-sm md:text-display">
            Soluciones para cada necesidad
          </h2>
        </div>

        {/* Business Lines */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {businessLines.map((line, index) => (
            <div
              key={line.title}
              className="group bg-white/5 backdrop-blur-sm rounded-lg overflow-hidden border border-white/10 hover:border-white/20 transition-colors opacity-0 animate-fade-in-up"
              style={{ animationDelay: `${index * 0.15}s` }}
            >
              <div className="aspect-[16/9] overflow-hidden">
                <img
                  src={line.image}
                  alt={line.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
                    <line.icon className="h-5 w-5" />
                  </div>
                  <h3 className="font-serif text-xl font-semibold">{line.title}</h3>
                </div>
                <p className="text-sm text-white/70 leading-relaxed mb-4">
                  {line.description}
                </p>
                <Button
                  asChild
                  variant="secondary"
                  className="w-full bg-white/10 hover:bg-white/20 border-0"
                >
                  <Link to={line.href}>Más información</Link>
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
