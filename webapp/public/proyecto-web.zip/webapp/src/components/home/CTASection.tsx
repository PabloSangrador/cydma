import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Phone, Mail, ArrowRight, Download } from "lucide-react";

export default function CTASection() {
  return (
    <section className="py-24">
      <div className="container">
        <div className="relative overflow-hidden rounded-2xl bg-secondary">
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-5">
            <div
              className="absolute inset-0"
              style={{
                backgroundImage:
                  "radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)",
                backgroundSize: "32px 32px",
              }}
            />
          </div>

          <div className="relative px-8 py-16 md:px-16 md:py-20 flex flex-col lg:flex-row items-center justify-between gap-10">
            {/* Text Content */}
            <div className="text-center lg:text-left max-w-xl">
              <h2 className="font-serif text-display-sm md:text-display text-foreground mb-4">
                ¿Necesita un presupuesto?
              </h2>
              <p className="text-lg text-muted-foreground mb-6">
                Nuestro equipo está preparado para asesorarle en su proyecto.
                Contacte con nosotros y reciba una propuesta personalizada.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button asChild size="lg" className="group">
                  <Link to="/contacto">
                    Contactar
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <a href="tel:983625022">
                    <Phone className="mr-2 h-4 w-4" />
                    983 625 022
                  </a>
                </Button>
              </div>
            </div>

            {/* Contact Info */}
            <div className="bg-background rounded-xl p-8 shadow-soft-lg min-w-[280px]">
              <h3 className="font-serif text-lg font-semibold mb-4">
                Información de Contacto
              </h3>
              <div className="space-y-4">
                <a
                  href="tel:983625022"
                  className="flex items-center gap-3 text-muted-foreground hover:text-primary transition-colors"
                >
                  <Phone className="h-5 w-5 text-accent" />
                  <span>983 625 022</span>
                </a>
                <a
                  href="mailto:cydma@cydma.es"
                  className="flex items-center gap-3 text-muted-foreground hover:text-primary transition-colors"
                >
                  <Mail className="h-5 w-5 text-accent" />
                  <span>cydma@cydma.es</span>
                </a>
                <a
                  href="mailto:export@cydma.es"
                  className="flex items-center gap-3 text-muted-foreground hover:text-primary transition-colors"
                >
                  <Mail className="h-5 w-5 text-accent" />
                  <span>export@cydma.es</span>
                </a>
              </div>
              <div className="mt-6 pt-4 border-t">
                <p className="text-sm text-muted-foreground">
                  <strong className="text-foreground">Ubicación:</strong>
                  <br />
                  Íscar, Valladolid, España
                </p>
              </div>
              <div className="mt-4 pt-4 border-t">
                <a
                  href="/cydma-codigo-fuente.zip"
                  download
                  className="flex items-center gap-3 text-muted-foreground hover:text-primary transition-colors"
                >
                  <Download className="h-5 w-5 text-accent" />
                  <span className="text-sm">Descargar código fuente</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
