import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { categories } from "@/data/catalog";

const featuredCategories = categories.slice(0, 6);

export default function CategoriesSection() {
  return (
    <section className="py-24">
      <div className="container">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <p className="text-accent font-medium tracking-wider uppercase text-sm mb-2">
              Nuestro Catálogo
            </p>
            <h2 className="font-serif text-display-sm md:text-display text-foreground">
              Productos de Calidad
            </h2>
          </div>
          <Link
            to="/catalogo"
            className="group inline-flex items-center gap-2 text-primary font-medium mt-4 md:mt-0 hover:underline"
          >
            Ver catálogo completo
            <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredCategories.map((category, index) => (
            <Link
              key={category.id}
              to={`/catalogo/${category.slug}`}
              className="group relative overflow-hidden rounded-lg aspect-[4/3] opacity-0 animate-fade-in-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <img
                src={category.image}
                alt={category.name}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="font-serif text-xl font-semibold text-white mb-1">
                  {category.name}
                </h3>
                <p className="text-sm text-white/70 line-clamp-2">
                  {category.description}
                </p>
                <div className="mt-3 flex items-center gap-2 text-white/90 text-sm font-medium opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all">
                  Ver productos
                  <ArrowRight className="h-4 w-4" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
