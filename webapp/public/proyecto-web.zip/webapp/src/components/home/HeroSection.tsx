import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative min-h-[85vh] flex items-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/edf-solar-autoconsumo-cydma-cyl-2.jpeg"
          alt="Carpintería industrial CYDMA"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/95 to-background/60" />
      </div>

      {/* Content */}
      <div className="container relative z-10">
        <div className="max-w-2xl">
          <p className="text-accent font-medium tracking-wider uppercase text-sm mb-4 opacity-0 animate-fade-in-up stagger-1">
            Desde 1989
          </p>
          <h1 className="font-serif text-display-sm md:text-display lg:text-display-lg text-foreground mb-6 opacity-0 animate-fade-in-up stagger-2">
            Referentes en el servicio integral de carpintería
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed opacity-0 animate-fade-in-up stagger-3">
            Más de 35 años de experiencia al servicio del profesional de la madera.
            Calidad, cercanía y excelencia en cada proyecto.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 opacity-0 animate-fade-in-up stagger-4">
            <Button asChild size="lg" className="group">
              <Link to="/catalogo">
                Ver Catálogo
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link to="/contacto">Solicitar Presupuesto</Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Decorative Element */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
}
