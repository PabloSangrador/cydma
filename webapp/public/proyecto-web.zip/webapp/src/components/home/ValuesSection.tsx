import { Award, Heart, Users, Globe, Shield } from "lucide-react";

const values = [
  {
    icon: Award,
    title: "Referentes",
    description: "Servicio integral de carpintería",
  },
  {
    icon: Shield,
    title: "Calidad",
    description: "Los más altos estándares",
  },
  {
    icon: Heart,
    title: "Cercanía",
    description: "Proyectos únicos, implicaciones únicas",
  },
  {
    icon: Users,
    title: "Profesionales",
    description: "+35 años de experiencia",
  },
  {
    icon: Globe,
    title: "Exportación",
    description: "Lo que quieras, donde elijas",
  },
];

export default function ValuesSection() {
  return (
    <section className="py-20 bg-secondary/30">
      <div className="container">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8">
          {values.map((value, index) => (
            <div
              key={value.title}
              className="text-center group opacity-0 animate-fade-in-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-background border border-border mb-4 group-hover:border-accent group-hover:bg-accent/5 transition-colors">
                <value.icon className="h-7 w-7 text-accent" />
              </div>
              <h3 className="font-serif text-lg font-semibold mb-1">{value.title}</h3>
              <p className="text-sm text-muted-foreground">{value.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
