import { Link } from "react-router-dom";
import { Phone, Mail, MapPin } from "lucide-react";
import { categories } from "@/data/catalog";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-primary-foreground">
      {/* Main Footer */}
      <div className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <Link to="/" className="inline-block mb-6">
              <img
                src="/logo-cydma-0002-blanco.png"
                alt="CYDMA - Carpintería Industrial"
                className="h-14 w-auto"
              />
            </Link>
            <p className="text-sm opacity-80 leading-relaxed mb-6">
              Referentes en el servicio integral de carpintería desde 1989.
              Más de 35 años de experiencia al servicio del profesional de la madera.
            </p>
            <div className="space-y-3">
              <a
                href="tel:983625022"
                className="flex items-center gap-3 text-sm hover:opacity-80 transition-opacity"
              >
                <Phone className="h-4 w-4" />
                983 625 022
              </a>
              <a
                href="mailto:cydma@cydma.es"
                className="flex items-center gap-3 text-sm hover:opacity-80 transition-opacity"
              >
                <Mail className="h-4 w-4" />
                cydma@cydma.es
              </a>
              <div className="flex items-start gap-3 text-sm opacity-80">
                <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>Íscar, Valladolid, España</span>
              </div>
            </div>
          </div>

          {/* Catálogo */}
          <div>
            <h3 className="font-serif text-lg font-semibold mb-5">Catálogo</h3>
            <ul className="space-y-2.5">
              {categories.slice(0, 6).map((category) => (
                <li key={category.id}>
                  <Link
                    to={`/catalogo/${category.slug}`}
                    className="text-sm opacity-80 hover:opacity-100 transition-opacity"
                  >
                    {category.name}
                  </Link>
                </li>
              ))}
              <li>
                <Link
                  to="/catalogo"
                  className="text-sm font-medium hover:underline"
                >
                  Ver todo el catálogo →
                </Link>
              </li>
            </ul>
          </div>

          {/* Servicios */}
          <div>
            <h3 className="font-serif text-lg font-semibold mb-5">Servicios</h3>
            <ul className="space-y-2.5">
              <li>
                <Link
                  to="/almacen"
                  className="text-sm opacity-80 hover:opacity-100 transition-opacity"
                >
                  Almacén
                </Link>
              </li>
              <li>
                <Link
                  to="/contract"
                  className="text-sm opacity-80 hover:opacity-100 transition-opacity"
                >
                  Contract
                </Link>
              </li>
              <li>
                <Link
                  to="/export"
                  className="text-sm opacity-80 hover:opacity-100 transition-opacity"
                >
                  Export
                </Link>
              </li>
              <li>
                <Link
                  to="/proyectos"
                  className="text-sm opacity-80 hover:opacity-100 transition-opacity"
                >
                  Proyectos Realizados
                </Link>
              </li>
              <li>
                <Link
                  to="/calculadora"
                  className="text-sm opacity-80 hover:opacity-100 transition-opacity"
                >
                  Calculadora
                </Link>
              </li>
              <li>
                <Link
                  to="/garantia"
                  className="text-sm opacity-80 hover:opacity-100 transition-opacity"
                >
                  Garantía
                </Link>
              </li>
            </ul>
          </div>

          {/* Exportación */}
          <div>
            <h3 className="font-serif text-lg font-semibold mb-5">Exportación</h3>
            <p className="text-sm opacity-80 leading-relaxed mb-4">
              Llevamos nuestros productos a todo el mundo. Proyectos internacionales
              con los más altos estándares de embalaje y envío.
            </p>
            <a
              href="mailto:export@cydma.es"
              className="inline-flex items-center gap-2 text-sm font-medium hover:underline"
            >
              <Mail className="h-4 w-4" />
              export@cydma.es
            </a>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="container py-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm opacity-70">
            © {currentYear} CYDMA. Todos los derechos reservados.
          </p>
          <div className="flex items-center gap-6">
            <Link to="/privacidad" className="text-sm opacity-70 hover:opacity-100 transition-opacity">
              Política de Privacidad
            </Link>
            <Link to="/legal" className="text-sm opacity-70 hover:opacity-100 transition-opacity">
              Aviso Legal
            </Link>
            <Link to="/cookies" className="text-sm opacity-70 hover:opacity-100 transition-opacity">
              Cookies
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
