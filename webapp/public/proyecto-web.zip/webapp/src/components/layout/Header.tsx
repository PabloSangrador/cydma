import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, Phone, Mail, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { categories } from "@/data/catalog";
import { cn } from "@/lib/utils";
import MegaMenu from "./MegaMenu";

const navLinks = [
  { href: "/", label: "Inicio" },
  { href: "/quienes-somos", label: "Quiénes Somos" },
  { href: "/catalogo", label: "Catálogo", hasMegaMenu: true },
  { href: "/puertas-medida", label: "Puertas a Medida" },
  { href: "/armarios-medida", label: "Armarios a Medida" },
  { href: "/almacen", label: "Almacén" },
  { href: "/contract", label: "Contract" },
  { href: "/export", label: "Export" },
  { href: "/contacto", label: "Contacto" },
];

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [megaMenuOpen, setMegaMenuOpen] = useState(false);
  const location = useLocation();

  const isActive = (href: string) => {
    if (href === "/") return location.pathname === "/";
    return location.pathname.startsWith(href);
  };

  return (
    <header className="sticky top-0 z-50 w-full">
      {/* Top bar */}
      <div className="bg-primary text-primary-foreground">
        <div className="container flex h-10 items-center justify-between text-sm">
          <div className="hidden md:flex items-center gap-6">
            <a href="tel:983625022" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <Phone className="h-3.5 w-3.5" />
              <span>983 625 022</span>
            </a>
            <a href="mailto:cydma@cydma.es" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <Mail className="h-3.5 w-3.5" />
              <span>cydma@cydma.es</span>
            </a>
          </div>
          <p className="text-center flex-1 md:flex-none md:text-right opacity-90">
            +35 años de experiencia en carpintería industrial
          </p>
        </div>
      </div>

      {/* Main navigation */}
      <nav className="bg-background/95 backdrop-blur-md border-b">
        <div className="container flex h-16 md:h-20 items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex-shrink-0">
            <img
              src="/logo-cydma-0006-corporativo.png"
              alt="CYDMA - Carpintería Industrial"
              className="h-12 md:h-14 w-auto object-contain"
            />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <div
                key={link.href}
                className="relative"
                onMouseEnter={() => link.hasMegaMenu && setMegaMenuOpen(true)}
                onMouseLeave={() => link.hasMegaMenu && setMegaMenuOpen(false)}
              >
                <Link
                  to={link.href}
                  className={cn(
                    "px-4 py-2 text-sm font-medium transition-colors rounded-md inline-flex items-center gap-1",
                    isActive(link.href)
                      ? "text-primary"
                      : "text-foreground/80 hover:text-primary hover:bg-secondary/50"
                  )}
                >
                  {link.label}
                  {link.hasMegaMenu && (
                    <ChevronDown className={cn(
                      "h-4 w-4 transition-transform",
                      megaMenuOpen && "rotate-180"
                    )} />
                  )}
                </Link>
                {link.hasMegaMenu && megaMenuOpen && (
                  <MegaMenu categories={categories} onClose={() => setMegaMenuOpen(false)} />
                )}
              </div>
            ))}
          </div>

          {/* CTA Button */}
          <div className="hidden lg:flex items-center gap-4">
            <Button asChild>
              <Link to="/contacto">Solicitar Presupuesto</Link>
            </Button>
          </div>

          {/* Mobile Menu */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild className="lg:hidden">
              <Button variant="ghost" size="icon">
                {mobileMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full sm:w-[400px] p-0">
              <div className="flex flex-col h-full">
                <div className="p-6 border-b">
                  <span className="font-serif text-2xl font-bold text-primary">CYDMA</span>
                </div>
                <nav className="flex-1 overflow-auto p-6">
                  <div className="space-y-1">
                    {navLinks.map((link) => (
                      <Link
                        key={link.href}
                        to={link.href}
                        onClick={() => setMobileMenuOpen(false)}
                        className={cn(
                          "block px-4 py-3 text-lg font-medium rounded-md transition-colors",
                          isActive(link.href)
                            ? "bg-primary text-primary-foreground"
                            : "hover:bg-secondary"
                        )}
                      >
                        {link.label}
                      </Link>
                    ))}
                  </div>

                  {/* Mobile Categories */}
                  <div className="mt-8">
                    <p className="px-4 text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                      Categorías
                    </p>
                    <div className="space-y-1">
                      {categories.map((category) => (
                        <Link
                          key={category.id}
                          to={`/catalogo/${category.slug}`}
                          onClick={() => setMobileMenuOpen(false)}
                          className="block px-4 py-2.5 text-base hover:bg-secondary rounded-md transition-colors"
                        >
                          {category.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                </nav>
                <div className="p-6 border-t space-y-4">
                  <div className="flex flex-col gap-2 text-sm">
                    <a href="tel:983625022" className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="h-4 w-4" />
                      983 625 022
                    </a>
                    <a href="mailto:cydma@cydma.es" className="flex items-center gap-2 text-muted-foreground">
                      <Mail className="h-4 w-4" />
                      cydma@cydma.es
                    </a>
                  </div>
                  <Button asChild className="w-full">
                    <Link to="/contacto" onClick={() => setMobileMenuOpen(false)}>
                      Solicitar Presupuesto
                    </Link>
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </nav>
    </header>
  );
}
