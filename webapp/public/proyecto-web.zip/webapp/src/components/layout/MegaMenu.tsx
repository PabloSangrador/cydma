import { Link } from "react-router-dom";
import { Category } from "@/data/catalog";
import { ChevronRight } from "lucide-react";

interface MegaMenuProps {
  categories: Category[];
  onClose: () => void;
}

export default function MegaMenu({ categories, onClose }: MegaMenuProps) {
  return (
    <div
      className="absolute top-full left-1/2 -translate-x-1/2 w-[800px] bg-card border rounded-lg shadow-elevated animate-slide-down"
      onMouseLeave={onClose}
    >
      <div className="p-6">
        <div className="grid grid-cols-3 gap-6">
          {categories.map((category) => (
            <div key={category.id} className="space-y-3">
              <Link
                to={`/catalogo/${category.slug}`}
                onClick={onClose}
                className="group flex items-center justify-between font-serif text-lg font-semibold text-foreground hover:text-primary transition-colors"
              >
                {category.name}
                <ChevronRight className="h-4 w-4 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
              </Link>

              {category.subcategories && category.subcategories.length > 0 && (
                <ul className="space-y-1.5">
                  {category.subcategories.slice(0, 5).map((sub) => (
                    <li key={sub.id}>
                      <Link
                        to={`/catalogo/${category.slug}/${sub.slug}`}
                        onClick={onClose}
                        className="text-sm text-muted-foreground hover:text-primary transition-colors"
                      >
                        {sub.name}
                      </Link>
                    </li>
                  ))}
                  {category.subcategories.length > 5 && (
                    <li>
                      <Link
                        to={`/catalogo/${category.slug}`}
                        onClick={onClose}
                        className="text-sm text-accent font-medium hover:underline"
                      >
                        Ver todas →
                      </Link>
                    </li>
                  )}
                </ul>
              )}
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-6 pt-6 border-t flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            ¿No encuentra lo que busca?
          </p>
          <Link
            to="/contacto"
            onClick={onClose}
            className="text-sm font-medium text-primary hover:underline"
          >
            Contáctenos para soluciones personalizadas →
          </Link>
        </div>
      </div>
    </div>
  );
}
