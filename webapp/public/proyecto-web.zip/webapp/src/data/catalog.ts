// CYDMA Product Catalog Data Structure

export interface Product {
  id: string;
  name: string;
  code: string;
  description: string;
  detailedDescription?: string;
  images: string[];
  categoryId: string;
  subcategoryId?: string;
  subsubcategoryId?: string;
  features?: string[];
  relatedProducts?: string[];
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: string;
  subcategories?: Subcategory[];
}

export interface Subcategory {
  id: string;
  name: string;
  slug: string;
  description?: string;
  image?: string;
  subcategories?: SubSubcategory[];
}

export interface SubSubcategory {
  id: string;
  name: string;
  slug: string;
  description?: string;
}

// Categories Structure
export const categories: Category[] = [
  {
    id: "puertas",
    name: "Puertas",
    slug: "puertas",
    description: "Puertas de interior de alta calidad en diversos acabados",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80",
    subcategories: [
      {
        id: "lisas",
        name: "Lisas",
        slug: "lisas",
        description: "Puertas de madera con diferentes tipos de veta"
      },
      {
        id: "fresadas",
        name: "Fresadas",
        slug: "fresadas",
        description: "Puertas con canales fresados sobre madera maciza"
      },
      {
        id: "lacadas",
        name: "Lacadas",
        slug: "lacadas",
        description: "Puertas lacadas en el RAL de su elección"
      },
      {
        id: "clasicas",
        name: "Clásicas",
        slug: "clasicas",
        description: "Puertas de madera clásica con plafones"
      },
      {
        id: "vinilo-2d",
        name: "Vinilo 2D",
        slug: "vinilo-2d",
        description: "Puertas de madera vanguardista en vinilo 2D"
      },
      {
        id: "vinilo-3d",
        name: "Vinilo 3D",
        slug: "vinilo-3d",
        description: "Puertas de madera vanguardista en vinilo 3D"
      }
    ]
  },
  {
    id: "armarios",
    name: "Armarios",
    slug: "armarios",
    description: "Soluciones de armarios modulares y personalizados",
    image: "https://images.unsplash.com/photo-1558997519-83ea9252edf8?w=800&q=80",
    subcategories: [
      {
        id: "abatibles",
        name: "Abatibles",
        slug: "abatibles",
        description: "Armarios a medida con hojas abatibles"
      },
      {
        id: "accesorios-armarios",
        name: "Accesorios",
        slug: "accesorios",
        description: "Complementos y herrajes funcionales"
      },
      {
        id: "correderos",
        name: "Correderos",
        slug: "correderos",
        description: "Armarios a medida con hojas deslizantes"
      },
      {
        id: "cristales",
        name: "Cristales",
        slug: "cristales",
        description: "Acabados en vidrio"
      },
      {
        id: "division-espacios",
        name: "División de espacios",
        slug: "division-espacios",
        description: "Proyectos a medida para componer espacios"
      },
      {
        id: "interiores",
        name: "Interiores",
        slug: "interiores",
        description: "Decenas de acabados modulables según la necesidad"
      },
      {
        id: "perfiles",
        name: "Perfiles",
        slug: "perfiles",
        description: "Acabados de perfilería"
      },
      {
        id: "vestidores",
        name: "Vestidores",
        slug: "vestidores",
        description: "Proyectos a medida para disfrutar y aprovechar los espacios"
      }
    ]
  },
  {
    id: "acorazadas",
    name: "Acorazadas",
    slug: "acorazadas",
    description: "Puertas de seguridad con los más altos estándares",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80",
    subcategories: [
      {
        id: "eco-t",
        name: "ECO-T",
        slug: "eco-t",
        description: "Fabricada para cubrir un mercado donde calidad y seguridad estén al alcance de cualquier bolsillo"
      },
      {
        id: "thor-20",
        name: "THOR-20",
        slug: "thor-20",
        description: "Fabricada cumpliendo las certificaciones de seguridad GRADO 3"
      },
      {
        id: "thor-20-plus",
        name: "THOR-20 PLUS",
        slug: "thor-20-plus",
        description: "PREMIUM 4C no es solo una puerta, es tranquilidad para ti y los tuyos"
      },
      {
        id: "premium-4c",
        name: "PREMIUM 4C",
        slug: "premium-4c",
        description: "Puerta electrónica"
      },
      {
        id: "idom",
        name: "IDOM",
        slug: "idom",
        description: "Con las características y garantía de la THOR 20 mas un PLUS en seguridad"
      },
      {
        id: "trastero",
        name: "TRASTERO",
        slug: "trastero",
        description: "Al igual que proteges la seguridad de tu hogar, protege también la del trastero"
      }
    ]
  },
  {
    id: "marcos-molduras",
    name: "Marcos y Molduras",
    slug: "marcos-molduras",
    description: "Marcos y molduras de alta calidad",
    image: "https://images.unsplash.com/photo-1600585154363-67eb9e2e2099?w=800&q=80",
    subcategories: [
      {
        id: "cercos",
        name: "Cercos",
        slug: "cercos",
        description: "Revestimientos de marcos en madera maciza o rechapada"
      },
      {
        id: "kits-revestimiento",
        name: "Kits de revestimiento",
        slug: "kits-revestimiento",
        description: "Revestimientos de armazones de corredera en madera maciza o rechapada"
      },
      {
        id: "molduras",
        name: "Molduras",
        slug: "molduras",
        description: "Tapajuntas rectos o extensibles en madera maciza o rechapados"
      }
    ]
  },
  {
    id: "fenolicas",
    name: "Soluciones Fenólicas",
    slug: "fenolicas",
    description: "Soluciones fenólicas para interior y exterior",
    image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80",
    subcategories: [
      {
        id: "cabinas",
        name: "Cabinas",
        slug: "cabinas",
        description: "Proyectos a medida de productos sanitarios fenólicos"
      },
      {
        id: "panelados",
        name: "Panelados",
        slug: "panelados",
        description: "Proyectos a medida de panelados decorativos interiores"
      },
      {
        id: "fachadas-ventiladas",
        name: "Fachadas ventiladas",
        slug: "fachadas-ventiladas",
        description: "Asesoramiento, fabricación e instalación de fachadas ventiladas fenólicas"
      }
    ]
  },
  {
    id: "herrajes",
    name: "Herrajes",
    slug: "herrajes",
    description: "Herrajes y accesorios para puertas",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80",
    subcategories: [
      {
        id: "bocallaves",
        name: "Bocallaves",
        slug: "bocallaves",
        description: "Bocallaves en diferentes acabados"
      },
      {
        id: "condenas",
        name: "Condenas",
        slug: "condenas",
        description: "Condenas para puertas"
      },
      {
        id: "mirillas",
        name: "Mirillas",
        slug: "mirillas",
        description: "Mirillas para puertas"
      },
      {
        id: "muelles-cierrapuertas",
        name: "Muelles cierrapuertas",
        slug: "muelles-cierrapuertas",
        description: "Cierrapuertas automáticos"
      },
      {
        id: "pomos",
        name: "Pomos",
        slug: "pomos",
        description: "Pomos para puertas"
      },
      {
        id: "bisagras",
        name: "Bisagras",
        slug: "bisagras",
        description: "Bisagras y pernios para puertas"
      },
      {
        id: "picaportes",
        name: "Picaportes",
        slug: "picaportes",
        description: "Picaportes para puertas"
      },
      {
        id: "cerraduras",
        name: "Cerraduras",
        slug: "cerraduras",
        description: "Cerraduras de seguridad"
      },
      {
        id: "rosetas-acero",
        name: "Rosetas de acero",
        slug: "rosetas-acero",
        description: "Rosetas fabricadas en acero inoxidable"
      },
      {
        id: "rosetas-aluminio",
        name: "Rosetas de aluminio",
        slug: "rosetas-aluminio",
        description: "Rosetas fabricadas en aluminio"
      },
      {
        id: "rosetas-zamak",
        name: "Rosetas de zamak",
        slug: "rosetas-zamak",
        description: "Rosetas fabricadas en zamak"
      },
      {
        id: "rosetas-premium",
        name: "Rosetas Premium",
        slug: "rosetas-premium",
        description: "Rosetas de gama premium"
      },
      {
        id: "placas-acero",
        name: "Placas de acero",
        slug: "placas-acero",
        description: "Placas fabricadas en acero inoxidable"
      },
      {
        id: "placas-aluminio",
        name: "Placas de aluminio",
        slug: "placas-aluminio",
        description: "Placas fabricadas en aluminio"
      },
      {
        id: "placas-laton",
        name: "Placas de latón",
        slug: "placas-laton",
        description: "Placas fabricadas en latón"
      },
      {
        id: "placas-zamak",
        name: "Placas de zamak",
        slug: "placas-zamak",
        description: "Placas fabricadas en zamak"
      },
      {
        id: "manillones",
        name: "Manillones",
        slug: "manillones",
        description: "Manillones para puertas de entrada"
      },
      {
        id: "guias-exteriores",
        name: "Guías exteriores",
        slug: "guias-exteriores",
        description: "Guías para puertas correderas exteriores"
      },
      {
        id: "tiradores-picos-loro",
        name: "Tiradores y picos de loro",
        slug: "tiradores-picos-loro",
        description: "Tiradores y picos de loro para puertas correderas"
      },
      {
        id: "herrajes-cabina",
        name: "Herrajes de cabina",
        slug: "herrajes-cabina",
        description: "Herrajes específicos para cabinas"
      }
    ]
  }
];

// Products Data
export const products: Product[] = [
  // ==================== PUERTAS LISAS ====================
  {
    id: "l-100",
    name: "L-100",
    code: "L-100",
    description: "Puerta de madera con veta vertical",
    detailedDescription: "Puerta de madera de alta calidad con diseño de veta vertical. Acabado elegante y duradero para cualquier estancia.",
    images: ["/l-100.jpeg"],
    categoryId: "puertas",
    subcategoryId: "lisas",
    features: ["Veta vertical", "Madera de alta calidad", "Acabado duradero"],
    relatedProducts: ["l-110", "l-120", "l-230"]
  },
  {
    id: "l-110",
    name: "L-110",
    code: "L-110",
    description: "Puerta de madera con veta horizontal",
    detailedDescription: "Puerta de madera con diseño de veta horizontal. Estilo moderno y minimalista para espacios contemporáneos.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "lisas",
    features: ["Veta horizontal", "Estilo moderno", "Diseño minimalista"],
    relatedProducts: ["l-100", "l-120", "l-230"]
  },
  {
    id: "l-120",
    name: "L-120",
    code: "L-120",
    description: "Puerta de madera con veta combinada",
    detailedDescription: "Puerta de madera con diseño de veta combinada. Combina lo mejor de ambos estilos para un resultado único.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "lisas",
    features: ["Veta combinada", "Diseño único", "Versatilidad"],
    relatedProducts: ["l-100", "l-110", "l-230"]
  },
  {
    id: "l-230",
    name: "L-230",
    code: "L-230",
    description: "Puerta de madera con veta combinada y grecas en madera",
    detailedDescription: "Puerta de madera con diseño de veta combinada y grecas decorativas. Elegancia y distinción para espacios especiales.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "lisas",
    features: ["Veta combinada", "Grecas decorativas", "Elegancia"],
    relatedProducts: ["l-100", "l-110", "l-120"]
  },

  // ==================== PUERTAS FRESADAS ====================
  {
    id: "f-520",
    name: "F-520",
    code: "F-520",
    description: "Puerta de madera con veta combinada y canales fresados sobre madera maciza",
    detailedDescription: "Puerta fresada de alta calidad con canales tallados sobre madera maciza. Diseño elegante con acabado premium.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "fresadas",
    features: ["Canales fresados", "Madera maciza", "Acabado premium"],
    relatedProducts: ["f-530", "f-544"]
  },
  {
    id: "f-530",
    name: "F-530",
    code: "F-530",
    description: "Puerta de madera con veta combinada y canales fresados sobre madera maciza",
    detailedDescription: "Puerta fresada con diseño distintivo de canales sobre madera maciza. Perfecta para ambientes con personalidad.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "fresadas",
    features: ["Canales fresados", "Madera maciza", "Diseño distintivo"],
    relatedProducts: ["f-520", "f-544"]
  },
  {
    id: "f-544",
    name: "F-544",
    code: "F-544",
    description: "Puerta de madera con veta combinada y canales fresados sobre madera maciza",
    detailedDescription: "Puerta fresada premium con acabado de alta calidad. Canales precisos sobre madera maciza seleccionada.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "fresadas",
    features: ["Canales fresados", "Madera maciza seleccionada", "Acabado de alta calidad"],
    relatedProducts: ["f-520", "f-530"]
  },

  // ==================== PUERTAS LACADAS ====================
  {
    id: "lac-100",
    name: "LAC-100",
    code: "LAC-100",
    description: "Puerta lisa lacada en el RAL de su elección",
    detailedDescription: "Puerta lisa lacada con acabado impecable. Disponible en cualquier color RAL para adaptarse a su decoración.",
    images: ["/lac-100.jpeg"],
    categoryId: "puertas",
    subcategoryId: "lacadas",
    features: ["Lacado en cualquier RAL", "Acabado liso", "Alta durabilidad"],
    relatedProducts: ["lac-210", "lac-214", "lac-510"]
  },
  {
    id: "lac-210",
    name: "LAC-210",
    code: "LAC-210",
    description: "Puerta con fresados lacada en el RAL de su elección",
    detailedDescription: "Puerta lacada con elegantes fresados decorativos. Personalizable en cualquier color RAL.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "lacadas",
    features: ["Fresados decorativos", "Lacado RAL", "Diseño elegante"],
    relatedProducts: ["lac-100", "lac-214", "lac-510"]
  },
  {
    id: "lac-214",
    name: "LAC-214",
    code: "LAC-214",
    description: "Puerta con fresados lacada en el RAL de su elección",
    detailedDescription: "Puerta lacada con diseño de fresados especiales. Acabado premium en el color RAL de su elección.",
    images: ["/lac-214.jpeg"],
    categoryId: "puertas",
    subcategoryId: "lacadas",
    features: ["Fresados especiales", "Acabado premium", "Color RAL personalizado"],
    relatedProducts: ["lac-100", "lac-210", "lac-510"]
  },
  {
    id: "lac-510",
    name: "LAC-510",
    code: "LAC-510",
    description: "Puerta con fresados lacada en el RAL de su elección",
    detailedDescription: "Puerta de la serie 500 con fresados distintivos. Lacada en cualquier color RAL.",
    images: ["/lac-510.jpeg"],
    categoryId: "puertas",
    subcategoryId: "lacadas",
    features: ["Serie 500", "Fresados distintivos", "Lacado RAL"],
    relatedProducts: ["lac-515", "lac-535", "lac-542"]
  },
  {
    id: "lac-515",
    name: "LAC-515",
    code: "LAC-515",
    description: "Puerta con fresados lacada en el RAL de su elección",
    detailedDescription: "Puerta lacada con diseño de fresados modernos. Ideal para espacios contemporáneos.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "lacadas",
    features: ["Fresados modernos", "Diseño contemporáneo", "Lacado de alta calidad"],
    relatedProducts: ["lac-510", "lac-535", "lac-542"]
  },
  {
    id: "lac-535",
    name: "LAC-535",
    code: "LAC-535",
    description: "Puerta con fresados lacada en el RAL de su elección",
    detailedDescription: "Puerta lacada con fresados de líneas depuradas. Elegancia y modernidad en un solo producto.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "lacadas",
    features: ["Líneas depuradas", "Elegancia moderna", "Acabado impecable"],
    relatedProducts: ["lac-510", "lac-515", "lac-542"]
  },
  {
    id: "lac-542",
    name: "LAC-542",
    code: "LAC-542",
    description: "Puerta con fresados lacada en el RAL de su elección",
    detailedDescription: "Puerta lacada con diseño sofisticado de fresados. Para los espacios más exigentes.",
    images: ["/lac-542.jpeg"],
    categoryId: "puertas",
    subcategoryId: "lacadas",
    features: ["Diseño sofisticado", "Alta exigencia", "Fresados premium"],
    relatedProducts: ["lac-535", "lac-544", "lac-544s"]
  },
  {
    id: "lac-544",
    name: "LAC-544",
    code: "LAC-544",
    description: "Puerta con fresados lacada en el RAL de su elección",
    detailedDescription: "Puerta lacada de la serie 544 con acabados de alta gama. Perfecta para proyectos exclusivos.",
    images: ["/lac-544.jpeg"],
    categoryId: "puertas",
    subcategoryId: "lacadas",
    features: ["Serie 544", "Alta gama", "Proyectos exclusivos"],
    relatedProducts: ["lac-542", "lac-544s", "lac-1c"]
  },
  {
    id: "lac-544s",
    name: "LAC-544S",
    code: "LAC-544S",
    description: "Puerta con fresados lacada en el RAL de su elección",
    detailedDescription: "Versión especial de la LAC-544 con detalles adicionales de diseño.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "lacadas",
    features: ["Edición especial", "Detalles adicionales", "Diseño exclusivo"],
    relatedProducts: ["lac-542", "lac-544", "lac-1c"]
  },
  {
    id: "lac-1c",
    name: "LAC-1C",
    code: "LAC-1C",
    description: "Puerta con diseños pantografiados lacada en el RAL de su elección",
    detailedDescription: "Puerta lacada con diseños pantografiados únicos. Tecnología de precisión para acabados perfectos.",
    images: ["/lac-1c.jpeg"],
    categoryId: "puertas",
    subcategoryId: "lacadas",
    features: ["Diseños pantografiados", "Precisión tecnológica", "Acabados perfectos"],
    relatedProducts: ["lac-2", "lac-3", "lac-3c"]
  },
  {
    id: "lac-2",
    name: "LAC-2",
    code: "LAC-2",
    description: "Puerta con diseños pantografiados lacada en el RAL de su elección",
    detailedDescription: "Puerta lacada con pantografiado de dos secciones. Diseño equilibrado y elegante.",
    images: ["/lac-2-1.jpeg"],
    categoryId: "puertas",
    subcategoryId: "lacadas",
    features: ["Dos secciones", "Diseño equilibrado", "Pantografiado de precisión"],
    relatedProducts: ["lac-1c", "lac-3", "lac-3c"]
  },
  {
    id: "lac-3",
    name: "LAC-3",
    code: "LAC-3",
    description: "Puerta con diseños pantografiados lacada en el RAL de su elección",
    detailedDescription: "Puerta lacada con pantografiado de tres secciones. Armonía y proporción perfectas.",
    images: ["/lac-3.jpeg"],
    categoryId: "puertas",
    subcategoryId: "lacadas",
    features: ["Tres secciones", "Armonía perfecta", "Proporciones ideales"],
    relatedProducts: ["lac-1c", "lac-2", "lac-3c"]
  },
  {
    id: "lac-3c",
    name: "LAC-3C",
    code: "LAC-3C",
    description: "Puerta con diseños pantografiados lacada en el RAL de su elección",
    detailedDescription: "Versión especial de la LAC-3 con detalles adicionales en el pantografiado.",
    images: ["/lac-3c.jpeg"],
    categoryId: "puertas",
    subcategoryId: "lacadas",
    features: ["Versión especial", "Detalles adicionales", "Pantografiado premium"],
    relatedProducts: ["lac-2", "lac-3", "lac-4c"]
  },
  {
    id: "lac-4c",
    name: "LAC-4C",
    code: "LAC-4C",
    description: "Puerta con diseños pantografiados lacada en el RAL de su elección",
    detailedDescription: "Puerta lacada con pantografiado de cuatro secciones. Máxima expresión del diseño clásico renovado.",
    images: ["/lac-4c.jpeg"],
    categoryId: "puertas",
    subcategoryId: "lacadas",
    features: ["Cuatro secciones", "Clásico renovado", "Diseño premium"],
    relatedProducts: ["lac-3", "lac-3c", "lac-5"]
  },
  {
    id: "lac-5",
    name: "LAC-5",
    code: "LAC-5",
    description: "Puerta con diseños pantografiados lacada en el RAL de su elección",
    detailedDescription: "Puerta lacada con pantografiado de cinco secciones. Para los espacios más distinguidos.",
    images: ["/lac-5-1.jpeg"],
    categoryId: "puertas",
    subcategoryId: "lacadas",
    features: ["Cinco secciones", "Alta distinción", "Espacios premium"],
    relatedProducts: ["lac-3c", "lac-4c"]
  },

  // ==================== PUERTAS CLÁSICAS ====================
  {
    id: "clasica-2",
    name: "2",
    code: "2",
    description: "Puerta de madera clásica con plafones",
    detailedDescription: "Puerta clásica de dos plafones. Estilo tradicional que nunca pasa de moda.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "clasicas",
    features: ["Dos plafones", "Estilo tradicional", "Elegancia atemporal"],
    relatedProducts: ["clasica-2tr", "clasica-4", "clasica-4tr"]
  },
  {
    id: "clasica-2tr",
    name: "2TR",
    code: "2TR",
    description: "Puerta de madera clásica con plafones",
    detailedDescription: "Variante de la puerta clásica de dos plafones con acabados especiales.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "clasicas",
    features: ["Dos plafones", "Acabados especiales", "Diseño clásico"],
    relatedProducts: ["clasica-2", "clasica-4", "clasica-4tr"]
  },
  {
    id: "clasica-4",
    name: "4",
    code: "4",
    description: "Puerta de madera clásica con plafones",
    detailedDescription: "Puerta clásica de cuatro plafones. Diseño tradicional con presencia imponente.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "clasicas",
    features: ["Cuatro plafones", "Presencia imponente", "Tradición"],
    relatedProducts: ["clasica-2", "clasica-2tr", "clasica-4tr"]
  },
  {
    id: "clasica-4tr",
    name: "4TR",
    code: "4TR",
    description: "Puerta de madera clásica con plafones",
    detailedDescription: "Variante de la puerta clásica de cuatro plafones con acabados especiales.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "clasicas",
    features: ["Cuatro plafones", "Acabados especiales", "Elegancia clásica"],
    relatedProducts: ["clasica-2tr", "clasica-4", "clasica-5"]
  },
  {
    id: "clasica-5",
    name: "5",
    code: "5",
    description: "Puerta de madera clásica con plafones",
    detailedDescription: "Puerta clásica de cinco plafones. Máxima expresión del estilo tradicional.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "clasicas",
    features: ["Cinco plafones", "Estilo tradicional", "Máxima elegancia"],
    relatedProducts: ["clasica-4", "clasica-4tr", "clasica-5tr"]
  },
  {
    id: "clasica-5tr",
    name: "5TR",
    code: "5TR",
    description: "Puerta de madera clásica con plafones",
    detailedDescription: "Variante de la puerta clásica de cinco plafones con acabados especiales.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "clasicas",
    features: ["Cinco plafones", "Acabados especiales", "Distinción"],
    relatedProducts: ["clasica-4tr", "clasica-5", "castellana"]
  },
  {
    id: "castellana",
    name: "Castellana",
    code: "Castellana",
    description: "Puerta de madera clásica con plafones",
    detailedDescription: "Puerta de estilo castellano tradicional. Diseño rústico con carácter auténtico.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "clasicas",
    features: ["Estilo castellano", "Diseño rústico", "Carácter auténtico"],
    relatedProducts: ["clasica-5", "clasica-5tr"]
  },

  // ==================== PUERTAS VINILO 2D ====================
  {
    id: "roble-siena",
    name: "Roble Siena",
    code: "Roble Siena",
    description: "Puerta de madera vanguardista en vinilo",
    detailedDescription: "Puerta con acabado vinilo 2D en tono Roble Siena. Diseño vanguardista y resistente.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "vinilo-2d",
    features: ["Vinilo 2D", "Tono Roble Siena", "Alta resistencia"],
    relatedProducts: ["glaciar", "vanille", "noyer"]
  },
  {
    id: "glaciar",
    name: "Glaciar",
    code: "Glaciar",
    description: "Puerta de madera vanguardista en vinilo",
    detailedDescription: "Puerta con acabado vinilo 2D en tono Glaciar. Luminosidad y frescura para cualquier espacio.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "vinilo-2d",
    features: ["Vinilo 2D", "Tono Glaciar", "Luminosidad"],
    relatedProducts: ["roble-siena", "vanille", "noyer"]
  },
  {
    id: "vanille",
    name: "Vanille",
    code: "Vanille",
    description: "Puerta de madera vanguardista en vinilo",
    detailedDescription: "Puerta con acabado vinilo 2D en tono Vanille. Calidez y elegancia en un solo producto.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "vinilo-2d",
    features: ["Vinilo 2D", "Tono Vanille", "Calidez elegante"],
    relatedProducts: ["roble-siena", "glaciar", "noyer"]
  },
  {
    id: "noyer",
    name: "Noyer",
    code: "Noyer",
    description: "Puerta de madera vanguardista en vinilo",
    detailedDescription: "Puerta con acabado vinilo 2D en tono Noyer. Sofisticación y profundidad visual.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "vinilo-2d",
    features: ["Vinilo 2D", "Tono Noyer", "Sofisticación"],
    relatedProducts: ["roble-siena", "glaciar", "vanille"]
  },

  // ==================== PUERTAS VINILO 3D ====================
  {
    id: "fresno-blanco",
    name: "Fresno Blanco",
    code: "Fresno Blanco",
    description: "Puerta de madera vanguardista en vinilo",
    detailedDescription: "Puerta con acabado vinilo 3D en tono Fresno Blanco. Textura realista y luminosidad excepcional.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "vinilo-3d",
    features: ["Vinilo 3D", "Fresno Blanco", "Textura realista"],
    relatedProducts: ["roble-labriego", "nacar"]
  },
  {
    id: "roble-labriego",
    name: "Roble Labriego",
    code: "Roble Labriego",
    description: "Puerta de madera vanguardista en vinilo",
    detailedDescription: "Puerta con acabado vinilo 3D en tono Roble Labriego. Carácter rústico con tecnología moderna.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "vinilo-3d",
    features: ["Vinilo 3D", "Roble Labriego", "Carácter rústico"],
    relatedProducts: ["fresno-blanco", "nacar"]
  },
  {
    id: "nacar",
    name: "Nácar",
    code: "Nácar",
    description: "Puerta de madera vanguardista en vinilo",
    detailedDescription: "Puerta con acabado vinilo 3D en tono Nácar. Brillo sutil y elegancia refinada.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "puertas",
    subcategoryId: "vinilo-3d",
    features: ["Vinilo 3D", "Tono Nácar", "Brillo sutil"],
    relatedProducts: ["fresno-blanco", "roble-labriego"]
  },

  // ==================== ARMARIOS ====================
  {
    id: "armario-abatibles",
    name: "Abatibles",
    code: "Abatibles",
    description: "Armarios a medida con hojas abatibles",
    detailedDescription: "Armarios completamente personalizables con sistema de apertura abatible. Máximo aprovechamiento del espacio.",
    images: ["https://images.unsplash.com/photo-1558997519-83ea9252edf8?w=800&q=80"],
    categoryId: "armarios",
    subcategoryId: "abatibles",
    features: ["Apertura abatible", "A medida", "Máximo aprovechamiento"],
    relatedProducts: ["armario-correderos", "armario-vestidores"]
  },
  {
    id: "armario-accesorios",
    name: "Accesorios",
    code: "Accesorios",
    description: "Complementos y herrajes funcionales",
    detailedDescription: "Amplia gama de accesorios para personalizar y optimizar el interior de tu armario.",
    images: ["https://images.unsplash.com/photo-1558997519-83ea9252edf8?w=800&q=80"],
    categoryId: "armarios",
    subcategoryId: "accesorios-armarios",
    features: ["Complementos", "Herrajes", "Organización"],
    relatedProducts: ["armario-interiores"]
  },
  {
    id: "armario-correderos",
    name: "Correderos",
    code: "Correderos",
    description: "Armarios a medida con hojas deslizantes",
    detailedDescription: "Armarios con sistema de puertas correderas. Ideal para espacios donde la apertura abatible no es posible.",
    images: ["https://images.unsplash.com/photo-1558997519-83ea9252edf8?w=800&q=80"],
    categoryId: "armarios",
    subcategoryId: "correderos",
    features: ["Puertas correderas", "Ahorro de espacio", "Diseño moderno"],
    relatedProducts: ["armario-abatibles", "armario-cristales"]
  },
  {
    id: "armario-cristales",
    name: "Cristales",
    code: "Cristales",
    description: "Acabados en vidrio",
    detailedDescription: "Puertas de armario con acabados en cristal. Elegancia y luminosidad para tu vestidor.",
    images: ["https://images.unsplash.com/photo-1558997519-83ea9252edf8?w=800&q=80"],
    categoryId: "armarios",
    subcategoryId: "cristales",
    features: ["Acabado cristal", "Elegancia", "Luminosidad"],
    relatedProducts: ["armario-correderos", "armario-perfiles"]
  },
  {
    id: "armario-division-espacios",
    name: "División de espacios",
    code: "División de espacios",
    description: "Proyectos a medida para componer espacios",
    detailedDescription: "Soluciones de armarios que funcionan como divisores de espacios. Funcionalidad y diseño integrados.",
    images: ["https://images.unsplash.com/photo-1558997519-83ea9252edf8?w=800&q=80"],
    categoryId: "armarios",
    subcategoryId: "division-espacios",
    features: ["Divide espacios", "Funcionalidad", "Diseño integrado"],
    relatedProducts: ["armario-vestidores"]
  },
  {
    id: "armario-interiores",
    name: "Interiores",
    code: "Interiores",
    description: "Decenas de acabados modulables según la necesidad",
    detailedDescription: "Configuración interior personalizada con múltiples opciones de organización y almacenamiento.",
    images: ["https://images.unsplash.com/photo-1558997519-83ea9252edf8?w=800&q=80"],
    categoryId: "armarios",
    subcategoryId: "interiores",
    features: ["Modulable", "Personalizado", "Múltiples opciones"],
    relatedProducts: ["armario-accesorios", "armario-vestidores"]
  },
  {
    id: "armario-perfiles",
    name: "Perfiles",
    code: "Perfiles",
    description: "Acabados de perfilería",
    detailedDescription: "Amplia variedad de perfiles para puertas de armario. Diferentes acabados y estilos disponibles.",
    images: ["https://images.unsplash.com/photo-1558997519-83ea9252edf8?w=800&q=80"],
    categoryId: "armarios",
    subcategoryId: "perfiles",
    features: ["Variedad de perfiles", "Diferentes acabados", "Múltiples estilos"],
    relatedProducts: ["armario-cristales", "armario-correderos"]
  },
  {
    id: "armario-vestidores",
    name: "Vestidores",
    code: "Vestidores",
    description: "Proyectos a medida para disfrutar y aprovechar los espacios",
    detailedDescription: "Vestidores completos diseñados a medida. El sueño de tener todo perfectamente organizado.",
    images: ["https://images.unsplash.com/photo-1558997519-83ea9252edf8?w=800&q=80"],
    categoryId: "armarios",
    subcategoryId: "vestidores",
    features: ["Vestidor completo", "A medida", "Organización perfecta"],
    relatedProducts: ["armario-interiores", "armario-abatibles"]
  },

  // ==================== ACORAZADAS ====================
  {
    id: "eco-t",
    name: "ECO-T",
    code: "ECO-T",
    description: "Fabricada para cubrir un mercado donde calidad y seguridad estén al alcance de cualquier bolsillo",
    detailedDescription: "Puerta acorazada de entrada con excelente relación calidad-precio. Seguridad accesible sin renunciar a la calidad.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "acorazadas",
    subcategoryId: "eco-t",
    features: ["Económica", "Calidad garantizada", "Seguridad básica"],
    relatedProducts: ["thor-20", "thor-20-plus"]
  },
  {
    id: "thor-20",
    name: "THOR-20",
    code: "THOR-20",
    description: "Fabricada cumpliendo las certificaciones de seguridad GRADO 3",
    detailedDescription: "Puerta acorazada certificada GRADO 3. Máxima seguridad para tu hogar con acabados de alta calidad.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "acorazadas",
    subcategoryId: "thor-20",
    features: ["Certificación GRADO 3", "Alta seguridad", "Acabados premium"],
    relatedProducts: ["eco-t", "thor-20-plus", "premium-4c"]
  },
  {
    id: "thor-20-plus",
    name: "THOR-20 PLUS",
    code: "THOR-20 PLUS",
    description: "PREMIUM 4C no es solo una puerta, es tranquilidad para ti y los tuyos",
    detailedDescription: "Versión mejorada de la THOR-20 con prestaciones adicionales de seguridad y acabados exclusivos.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "acorazadas",
    subcategoryId: "thor-20-plus",
    features: ["THOR-20 mejorada", "Prestaciones adicionales", "Acabados exclusivos"],
    relatedProducts: ["thor-20", "premium-4c", "idom"]
  },
  {
    id: "premium-4c",
    name: "PREMIUM 4C",
    code: "PREMIUM 4C",
    description: "Puerta electrónica",
    detailedDescription: "Puerta acorazada con sistema electrónico integrado. La última tecnología en seguridad para el hogar.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "acorazadas",
    subcategoryId: "premium-4c",
    features: ["Sistema electrónico", "Última tecnología", "Máxima seguridad"],
    relatedProducts: ["thor-20-plus", "idom"]
  },
  {
    id: "idom",
    name: "IDOM",
    code: "IDOM",
    description: "Con las características y garantía de la THOR 20 mas un PLUS en seguridad",
    detailedDescription: "Puerta acorazada de alta gama con todas las características de la THOR 20 más prestaciones adicionales de seguridad.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "acorazadas",
    subcategoryId: "idom",
    features: ["Alta gama", "THOR 20 mejorada", "Seguridad plus"],
    relatedProducts: ["thor-20-plus", "premium-4c", "trastero"]
  },
  {
    id: "trastero",
    name: "TRASTERO",
    code: "TRASTERO",
    description: "Al igual que proteges la seguridad de tu hogar, protege también la del trastero",
    detailedDescription: "Puerta acorazada específica para trasteros. Protege tus pertenencias con la misma seguridad que tu hogar.",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "acorazadas",
    subcategoryId: "trastero",
    features: ["Para trasteros", "Seguridad completa", "Robusta y funcional"],
    relatedProducts: ["eco-t", "idom"]
  },

  // ==================== MARCOS Y MOLDURAS ====================
  {
    id: "cercos",
    name: "Cercos",
    code: "Cercos",
    description: "Revestimientos de marcos en madera maciza o rechapada",
    detailedDescription: "Cercos de alta calidad para enmarcar puertas. Disponibles en madera maciza o rechapada.",
    images: ["https://images.unsplash.com/photo-1600585154363-67eb9e2e2099?w=800&q=80"],
    categoryId: "marcos-molduras",
    subcategoryId: "cercos",
    features: ["Madera maciza", "Rechapado", "Alta calidad"],
    relatedProducts: ["kits-revestimiento", "molduras"]
  },
  {
    id: "kits-revestimiento",
    name: "Kits de revestimiento",
    code: "Kits de revestimiento",
    description: "Revestimientos de armazones de corredera en madera maciza o rechapada",
    detailedDescription: "Kits completos para revestir armazones de puertas correderas. Acabados en madera maciza o rechapada.",
    images: ["https://images.unsplash.com/photo-1600585154363-67eb9e2e2099?w=800&q=80"],
    categoryId: "marcos-molduras",
    subcategoryId: "kits-revestimiento",
    features: ["Kit completo", "Para correderas", "Varios acabados"],
    relatedProducts: ["cercos", "molduras"]
  },
  {
    id: "molduras",
    name: "Molduras",
    code: "Molduras",
    description: "Tapajuntas rectos o extensibles en madera maciza o rechapados",
    detailedDescription: "Molduras y tapajuntas para un acabado perfecto. Disponibles en versiones rectas o extensibles.",
    images: ["https://images.unsplash.com/photo-1600585154363-67eb9e2e2099?w=800&q=80"],
    categoryId: "marcos-molduras",
    subcategoryId: "molduras",
    features: ["Tapajuntas", "Rectos o extensibles", "Acabado perfecto"],
    relatedProducts: ["cercos", "kits-revestimiento"]
  },

  // ==================== SOLUCIONES FENÓLICAS ====================
  {
    id: "cabinas",
    name: "Cabinas",
    code: "Cabinas",
    description: "Proyectos a medida de productos sanitarios fenólicos",
    detailedDescription: "Cabinas sanitarias fenólicas para proyectos comerciales y públicos. Alta resistencia y fácil mantenimiento.",
    images: ["https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80"],
    categoryId: "fenolicas",
    subcategoryId: "cabinas",
    features: ["Fenólico sanitario", "Alta resistencia", "Fácil mantenimiento"],
    relatedProducts: ["panelados", "fachadas-ventiladas"]
  },
  {
    id: "panelados",
    name: "Panelados",
    code: "Panelados",
    description: "Proyectos a medida de panelados decorativos interiores",
    detailedDescription: "Panelados decorativos fenólicos para interiores. Estética y funcionalidad en espacios comerciales.",
    images: ["https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80"],
    categoryId: "fenolicas",
    subcategoryId: "panelados",
    features: ["Panelado decorativo", "Para interiores", "Estética y función"],
    relatedProducts: ["cabinas", "fachadas-ventiladas"]
  },
  {
    id: "fachadas-ventiladas",
    name: "Fachadas ventiladas",
    code: "Fachadas ventiladas",
    description: "Asesoramiento, fabricación e instalación de fachadas ventiladas fenólicas",
    detailedDescription: "Servicio integral de fachadas ventiladas fenólicas. Desde el asesoramiento hasta la instalación completa.",
    images: ["https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80"],
    categoryId: "fenolicas",
    subcategoryId: "fachadas-ventiladas",
    features: ["Servicio integral", "Fachadas ventiladas", "Fenólico exterior"],
    relatedProducts: ["cabinas", "panelados"]
  },

  // ==================== HERRAJES - BOCALLAVES ====================
  {
    id: "bocallave-cuadrado",
    name: "Bocallave cuadrado",
    code: "Bocallave cuadrado",
    description: "Bocallave de diseño cuadrado",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "bocallaves",
    relatedProducts: ["bocallave-laton", "bocallave-redondo"]
  },
  {
    id: "bocallave-laton",
    name: "Bocallave latón",
    code: "Bocallave latón",
    description: "Bocallave en acabado latón",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "bocallaves",
    relatedProducts: ["bocallave-cuadrado", "bocallave-redondo"]
  },
  {
    id: "bocallave-redondo",
    name: "Bocallave redondo",
    code: "Bocallave redondo",
    description: "Bocallave de diseño redondo",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "bocallaves",
    relatedProducts: ["bocallave-cuadrado", "bocallave-laton"]
  },

  // ==================== HERRAJES - CONDENAS ====================
  {
    id: "condena-cuadrada",
    name: "Condena cuadrada",
    code: "Condena cuadrada",
    description: "Condena de diseño cuadrado",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "condenas",
    relatedProducts: ["condena-redonda", "condena-laton"]
  },
  {
    id: "condena-redonda",
    name: "Condena redonda",
    code: "Condena redonda",
    description: "Condena de diseño redondo",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "condenas",
    relatedProducts: ["condena-cuadrada", "condena-laton"]
  },
  {
    id: "condena-laton",
    name: "Condena latón",
    code: "Condena latón",
    description: "Condena en acabado latón",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "condenas",
    relatedProducts: ["condena-cuadrada", "condena-redonda"]
  },

  // ==================== HERRAJES - MIRILLAS ====================
  {
    id: "mirilla-digital",
    name: "Mirilla digital",
    code: "Mirilla digital",
    description: "Mirilla con pantalla digital",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "mirillas",
    relatedProducts: ["mirilla-inox", "mirilla-mixta"]
  },
  {
    id: "mirilla-inox",
    name: "Mirilla inox",
    code: "Mirilla inox",
    description: "Mirilla en acero inoxidable",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "mirillas",
    relatedProducts: ["mirilla-digital", "mirilla-mixta"]
  },
  {
    id: "mirilla-mixta",
    name: "Mirilla mixta",
    code: "Mirilla mixta",
    description: "Mirilla de diseño mixto",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "mirillas",
    relatedProducts: ["mirilla-digital", "mirilla-inox"]
  },

  // ==================== HERRAJES - MUELLES CIERRAPUERTAS ====================
  {
    id: "cierrapuertas-inox",
    name: "Cierrapuertas inox",
    code: "Cierrapuertas inox",
    description: "Cierrapuertas en acero inoxidable",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "muelles-cierrapuertas",
    relatedProducts: ["cierrapuertas-negro"]
  },
  {
    id: "cierrapuertas-negro",
    name: "Cierrapuertas negro",
    code: "Cierrapuertas negro",
    description: "Cierrapuertas en acabado negro",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "muelles-cierrapuertas",
    relatedProducts: ["cierrapuertas-inox"]
  },

  // ==================== HERRAJES - POMOS ====================
  {
    id: "pomo-bronce",
    name: "Pomo bronce",
    code: "Pomo bronce",
    description: "Pomo en acabado bronce",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "pomos",
    relatedProducts: ["pomo-dorado", "pomo-inox"]
  },
  {
    id: "pomo-dorado",
    name: "Pomo dorado",
    code: "Pomo dorado",
    description: "Pomo en acabado dorado",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "pomos",
    relatedProducts: ["pomo-bronce", "pomo-inox"]
  },
  {
    id: "pomo-inox",
    name: "Pomo inox",
    code: "Pomo inox",
    description: "Pomo en acero inoxidable",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "pomos",
    relatedProducts: ["pomo-bronce", "pomo-dorado"]
  },

  // ==================== HERRAJES - BISAGRAS ====================
  {
    id: "bisagra-antipalanca-inox",
    name: "Bisagra antipalanca inox",
    code: "Bisagra antipalanca inox",
    description: "Bisagra antipalanca en acero inoxidable",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "bisagras",
    relatedProducts: ["bisagra-antipalanca-negra", "bisagra-oculta"]
  },
  {
    id: "bisagra-antipalanca-negra",
    name: "Bisagra antipalanca negra",
    code: "Bisagra antipalanca negra",
    description: "Bisagra antipalanca en acabado negro",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "bisagras",
    relatedProducts: ["bisagra-antipalanca-inox", "bisagra-oculta"]
  },
  {
    id: "bisagra-doble-accion",
    name: "Bisagra doble acción",
    code: "Bisagra doble acción",
    description: "Bisagra de doble acción (vaivén)",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "bisagras",
    relatedProducts: ["bisagra-oculta", "bisagra-cazoleta"]
  },
  {
    id: "bisagra-oculta",
    name: "Bisagra oculta",
    code: "Bisagra oculta",
    description: "Bisagra oculta para puertas",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "bisagras",
    relatedProducts: ["bisagra-antipalanca-inox", "bisagra-doble-accion"]
  },
  {
    id: "bisagra-cazoleta",
    name: "Bisagras de cazoleta",
    code: "Bisagras de cazoleta",
    description: "Bisagras de cazoleta para muebles",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "bisagras",
    relatedProducts: ["bisagra-oculta", "pernio-inox"]
  },
  {
    id: "pernio-bronce",
    name: "Pernio bronce",
    code: "Pernio bronce",
    description: "Pernio en acabado bronce",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "bisagras",
    relatedProducts: ["pernio-dorado", "pernio-inox"]
  },
  {
    id: "pernio-dorado",
    name: "Pernio dorado",
    code: "Pernio dorado",
    description: "Pernio en acabado dorado",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "bisagras",
    relatedProducts: ["pernio-bronce", "pernio-inox"]
  },
  {
    id: "pernio-inox",
    name: "Pernio inox",
    code: "Pernio inox",
    description: "Pernio en acero inoxidable",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "bisagras",
    relatedProducts: ["pernio-bronce", "pernio-dorado"]
  },
  {
    id: "pernio-negro",
    name: "Pernio negro",
    code: "Pernio negro",
    description: "Pernio en acabado negro",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "bisagras",
    relatedProducts: ["pernio-inox", "pernio-pala"]
  },
  {
    id: "pernio-pala",
    name: "Pernio pala",
    code: "Pernio pala",
    description: "Pernio tipo pala",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "bisagras",
    relatedProducts: ["pernio-negro", "pernio-inox"]
  },

  // ==================== HERRAJES - PICAPORTES ====================
  {
    id: "picaporte-magnetico",
    name: "Picaporte magnético",
    code: "Picaporte magnético",
    description: "Picaporte con cierre magnético silencioso",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "picaportes",
    relatedProducts: ["picaporte-unificado"]
  },
  {
    id: "picaporte-unificado",
    name: "Picaporte unificado",
    code: "Picaporte unificado",
    description: "Picaporte unificado estándar",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "picaportes",
    relatedProducts: ["picaporte-magnetico"]
  },

  // ==================== HERRAJES - CERRADURAS ====================
  {
    id: "cerradura-700b",
    name: "Cerradura 700B",
    code: "Cerradura 700B",
    description: "Cerradura modelo 700B",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "cerraduras",
    relatedProducts: ["cerradura-2010", "cerradura-3040"]
  },
  {
    id: "cerradura-2010",
    name: "Cerradura 2010",
    code: "Cerradura 2010",
    description: "Cerradura modelo 2010",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "cerraduras",
    relatedProducts: ["cerradura-700b", "cerradura-3040"]
  },
  {
    id: "cerradura-3040",
    name: "Cerradura 3040",
    code: "Cerradura 3040",
    description: "Cerradura modelo 3040",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "cerraduras",
    relatedProducts: ["cerradura-2010", "cerradura-9044"]
  },
  {
    id: "cerradura-9044",
    name: "Cerradura 9044",
    code: "Cerradura 9044",
    description: "Cerradura modelo 9044",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "cerraduras",
    relatedProducts: ["cerradura-3040", "cerradura-2000bz"]
  },
  {
    id: "cerradura-2000bz",
    name: "Cerradura 2000BZ",
    code: "Cerradura 2000BZ",
    description: "Cerradura modelo 2000BZ",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "cerraduras",
    relatedProducts: ["cerradura-9044", "cerradura-700b"]
  },

  // ==================== HERRAJES - ROSETAS DE ACERO ====================
  {
    id: "roseta-arco-inox",
    name: "Roseta Arco inox",
    code: "Roseta Arco inox",
    description: "Roseta modelo Arco en acero inoxidable",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "rosetas-acero",
    relatedProducts: ["roseta-elora-inox", "roseta-l-inox"]
  },
  {
    id: "roseta-elora-inox",
    name: "Roseta Elora inox",
    code: "Roseta Elora inox",
    description: "Roseta modelo Elora en acero inoxidable",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "rosetas-acero",
    relatedProducts: ["roseta-arco-inox", "roseta-recta-inox"]
  },
  {
    id: "roseta-l-inox",
    name: "Roseta L inox",
    code: "Roseta L inox",
    description: "Roseta modelo L en acero inoxidable",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "rosetas-acero",
    relatedProducts: ["roseta-arco-inox", "roseta-u-inox"]
  },
  {
    id: "roseta-recta-inox",
    name: "Roseta Recta inox",
    code: "Roseta Recta inox",
    description: "Roseta modelo Recta en acero inoxidable",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "rosetas-acero",
    relatedProducts: ["roseta-elora-inox", "roseta-u-inox"]
  },
  {
    id: "roseta-u-inox",
    name: "Roseta U inox",
    code: "Roseta U inox",
    description: "Roseta modelo U en acero inoxidable",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "rosetas-acero",
    relatedProducts: ["roseta-l-inox", "roseta-recta-inox"]
  },

  // ==================== HERRAJES - ROSETAS DE ALUMINIO (muestra) ====================
  {
    id: "roseta-8801-aluminio-cuadrada",
    name: "Roseta 8801 aluminio cuadrada",
    code: "Roseta 8801 aluminio cuadrada",
    description: "Roseta modelo 8801 en aluminio formato cuadrado",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "rosetas-aluminio",
    relatedProducts: ["roseta-8801-aluminio", "roseta-alena-aluminio"]
  },
  {
    id: "roseta-8801-aluminio",
    name: "Roseta 8801 aluminio",
    code: "Roseta 8801 aluminio",
    description: "Roseta modelo 8801 en aluminio",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "rosetas-aluminio",
    relatedProducts: ["roseta-8801-aluminio-cuadrada", "roseta-alena-aluminio"]
  },
  {
    id: "roseta-alena-aluminio",
    name: "Roseta Alena aluminio",
    code: "Roseta Alena aluminio",
    description: "Roseta modelo Alena en aluminio",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "rosetas-aluminio",
    relatedProducts: ["roseta-8801-aluminio", "roseta-ariane-aluminio"]
  },

  // ==================== HERRAJES - ROSETAS PREMIUM ====================
  {
    id: "roseta-atenea",
    name: "Roseta Atenea",
    code: "Roseta Atenea",
    description: "Roseta premium modelo Atenea",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "rosetas-premium",
    relatedProducts: ["roseta-aura", "roseta-hera"]
  },
  {
    id: "roseta-aura",
    name: "Roseta Aura",
    code: "Roseta Aura",
    description: "Roseta premium modelo Aura",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "rosetas-premium",
    relatedProducts: ["roseta-atenea", "roseta-hera"]
  },
  {
    id: "roseta-hera",
    name: "Roseta Hera",
    code: "Roseta Hera",
    description: "Roseta premium modelo Hera",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "rosetas-premium",
    relatedProducts: ["roseta-aura", "roseta-saga"]
  },
  {
    id: "roseta-saga",
    name: "Roseta Saga",
    code: "Roseta Saga",
    description: "Roseta premium modelo Saga",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "rosetas-premium",
    relatedProducts: ["roseta-hera", "roseta-talia"]
  },
  {
    id: "roseta-talia",
    name: "Roseta Talia",
    code: "Roseta Talia",
    description: "Roseta premium modelo Talia",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "rosetas-premium",
    relatedProducts: ["roseta-saga", "roseta-atenea"]
  },

  // ==================== HERRAJES - MANILLONES ====================
  {
    id: "manillon-911",
    name: "Manillon 911",
    code: "Manillon 911",
    description: "Manillón modelo 911",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "manillones",
    relatedProducts: ["manillon-910", "manillon-950"]
  },
  {
    id: "manillon-910",
    name: "Manillon 910",
    code: "Manillon 910",
    description: "Manillón modelo 910",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "manillones",
    relatedProducts: ["manillon-911", "manillon-950"]
  },
  {
    id: "manillon-recto-inox",
    name: "Manillon Recto inox",
    code: "Manillon Recto inox",
    description: "Manillón recto en acero inoxidable",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "manillones",
    relatedProducts: ["manillon-u-inox", "manillon-elora"]
  },

  // ==================== HERRAJES - GUÍAS EXTERIORES ====================
  {
    id: "guia-exterior-granero",
    name: "Guía exterior granero",
    code: "Guía exterior granero",
    description: "Guía exterior estilo granero",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "guias-exteriores",
    relatedProducts: ["guia-exterior-inox"]
  },
  {
    id: "guia-exterior-inox",
    name: "Guía exterior inox",
    code: "Guía exterior inox",
    description: "Guía exterior en acero inoxidable",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "guias-exteriores",
    relatedProducts: ["guia-exterior-granero"]
  },

  // ==================== HERRAJES - TIRADORES Y PICOS DE LORO ====================
  {
    id: "pico-loro-cerradura-cuadrado",
    name: "Pico de loro cerradura cuadrado",
    code: "Pico de loro cerradura cuadrado",
    description: "Pico de loro con cerradura formato cuadrado",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "tiradores-picos-loro",
    relatedProducts: ["pico-loro-cerradura", "pico-loro-condena-cuadrado"]
  },
  {
    id: "pico-loro-cerradura",
    name: "Pico de loro cerradura",
    code: "Pico de loro cerradura",
    description: "Pico de loro con cerradura",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "tiradores-picos-loro",
    relatedProducts: ["pico-loro-cerradura-cuadrado", "pico-loro-condena"]
  },
  {
    id: "tirador-cazoleta-redondo",
    name: "Tirador de cazoleta redondo",
    code: "Tirador de cazoleta redondo",
    description: "Tirador de cazoleta redondo para puertas correderas",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "tiradores-picos-loro",
    relatedProducts: ["tirador-cazoleta-cuadrado", "tirador-cazoleta-negro"]
  },
  {
    id: "tirador-cazoleta-cuadrado",
    name: "Tirador de cazoleta cuadrado",
    code: "Tirador de cazoleta cuadrado",
    description: "Tirador de cazoleta cuadrado para puertas correderas",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "tiradores-picos-loro",
    relatedProducts: ["tirador-cazoleta-redondo", "tirador-cazoleta-negro-cuadrado"]
  },

  // ==================== HERRAJES - HERRAJES DE CABINA ====================
  {
    id: "herrajes-cabina",
    name: "Herrajes de cabina",
    code: "Herrajes de cabina",
    description: "Herrajes específicos para cabinas sanitarias",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80"],
    categoryId: "herrajes",
    subcategoryId: "herrajes-cabina",
    relatedProducts: ["cabinas"]
  }
];

// Helper functions
export function getCategoryBySlug(slug: string): Category | undefined {
  return categories.find(c => c.slug === slug);
}

export function getSubcategoryBySlug(categorySlug: string, subcategorySlug: string): Subcategory | undefined {
  const category = getCategoryBySlug(categorySlug);
  return category?.subcategories?.find(s => s.slug === subcategorySlug);
}

export function getProductsByCategory(categoryId: string): Product[] {
  return products.filter(p => p.categoryId === categoryId);
}

export function getProductsBySubcategory(categoryId: string, subcategoryId: string): Product[] {
  return products.filter(p => p.categoryId === categoryId && p.subcategoryId === subcategoryId);
}

export function getProductById(id: string): Product | undefined {
  return products.find(p => p.id === id);
}

export function getProductByCode(code: string): Product | undefined {
  return products.find(p => p.code.toLowerCase() === code.toLowerCase());
}

export function getRelatedProducts(productId: string): Product[] {
  const product = getProductById(productId);
  if (!product?.relatedProducts) return [];
  return product.relatedProducts
    .map(id => getProductById(id))
    .filter((p): p is Product => p !== undefined);
}

export function searchProducts(query: string): Product[] {
  const lowercaseQuery = query.toLowerCase();
  return products.filter(p =>
    p.name.toLowerCase().includes(lowercaseQuery) ||
    p.code.toLowerCase().includes(lowercaseQuery) ||
    p.description.toLowerCase().includes(lowercaseQuery)
  );
}

// Get all products count for a category (including subcategories)
export function getProductCountByCategory(categoryId: string): number {
  return products.filter(p => p.categoryId === categoryId).length;
}

// Get all products count for a subcategory
export function getProductCountBySubcategory(categoryId: string, subcategoryId: string): number {
  return products.filter(p => p.categoryId === categoryId && p.subcategoryId === subcategoryId).length;
}
