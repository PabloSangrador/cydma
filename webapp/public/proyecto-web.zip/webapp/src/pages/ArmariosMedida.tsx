import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Check, Phone, Mail, Truck, Shield, Ruler, Palette, Info } from "lucide-react";

// Configuración de opciones del armario
const tiposArmario = [
  { id: "empotrado", label: "Empotrado", description: "Se integra en el hueco de la pared" },
  { id: "exento", label: "Exento / De pie", description: "Armario independiente con laterales" },
];

const tiposPuerta = [
  { id: "sin-puertas", label: "Sin puertas", precio: 0 },
  { id: "abatibles", label: "Puertas abatibles", precio: 120 },
  { id: "correderas", label: "Puertas correderas", precio: 180 },
  { id: "plegables", label: "Puertas plegables", precio: 150 },
];

const acabados = [
  { id: "melamina-blanco", label: "Melamina Blanco", precio: 0 },
  { id: "melamina-roble", label: "Melamina Roble", precio: 30 },
  { id: "melamina-nogal", label: "Melamina Nogal", precio: 30 },
  { id: "lacado-mate", label: "Lacado Mate", precio: 80 },
  { id: "lacado-brillo", label: "Lacado Alto Brillo", precio: 120 },
];

const interiores = [
  { id: "basico", label: "Básico", description: "Baldas y barra", precio: 0 },
  { id: "completo", label: "Completo", description: "Baldas, barras, cajones y zapatero", precio: 150 },
  { id: "vestidor", label: "Vestidor Premium", description: "Configuración completa con iluminación", precio: 280 },
];

const coloresPuerta = [
  { id: "blanco", label: "Blanco", hex: "#FFFFFF" },
  { id: "gris-claro", label: "Gris Claro", hex: "#D1D5DB" },
  { id: "gris-oscuro", label: "Gris Oscuro", hex: "#4B5563" },
  { id: "negro", label: "Negro", hex: "#1F2937" },
  { id: "roble-natural", label: "Roble Natural", hex: "#C4A77D" },
  { id: "nogal", label: "Nogal", hex: "#5D4037" },
  { id: "espejo", label: "Espejo", hex: "#E5E7EB" },
];

// Precio base por metro cuadrado
const PRECIO_BASE_M2 = 280;

export default function ArmariosMedida() {
  // Estado del configurador
  const [tipoArmario, setTipoArmario] = useState("empotrado");
  const [ancho, setAncho] = useState(200);
  const [alto, setAlto] = useState(250);
  const [profundidad, setProfundidad] = useState(60);
  const [tipoPuerta, setTipoPuerta] = useState("correderas");
  const [acabado, setAcabado] = useState("melamina-blanco");
  const [interior, setInterior] = useState("basico");
  const [colorPuerta, setColorPuerta] = useState("blanco");
  const [numPuertas, setNumPuertas] = useState(3);

  // Cálculo del precio estimado
  const precioEstimado = useMemo(() => {
    const m2 = (ancho / 100) * (alto / 100);
    const precioBase = m2 * PRECIO_BASE_M2;

    const puertaSeleccionada = tiposPuerta.find(p => p.id === tipoPuerta);
    const precioPuertas = (puertaSeleccionada?.precio || 0) * numPuertas;

    const acabadoSeleccionado = acabados.find(a => a.id === acabado);
    const precioAcabado = (acabadoSeleccionado?.precio || 0) * m2;

    const interiorSeleccionado = interiores.find(i => i.id === interior);
    const precioInterior = interiorSeleccionado?.precio || 0;

    // Suplemento por armario exento (tiene laterales)
    const suplementoExento = tipoArmario === "exento" ? precioBase * 0.15 : 0;

    return Math.round(precioBase + precioPuertas + precioAcabado + precioInterior + suplementoExento);
  }, [ancho, alto, tipoPuerta, acabado, interior, tipoArmario, numPuertas]);

  const caracteristicas = [
    "Fabricación 100% a medida",
    "Materiales de primera calidad",
    "Tableros de 19mm de grosor",
    "Cantos ABS de 2mm",
    "Herrajes de alta resistencia",
    "Garantía de 5 años",
    "Entrega e instalación incluida",
    "Diseño personalizado",
  ];

  return (
    <Layout>
      {/* Breadcrumb */}
      <div className="bg-secondary/30 border-b">
        <div className="container py-4">
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink asChild>
                  <Link to="/">Inicio</Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink asChild>
                  <Link to="/catalogo">Catálogo</Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbPage>Armarios a Medida</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative py-16 md:py-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
        <div className="container relative">
          <div className="max-w-3xl mx-auto text-center animate-fade-in-up">
            <h1 className="font-serif text-display-sm md:text-display text-foreground mb-6">
              Armarios a Medida
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8">
              Diseña tu armario perfecto. Totalmente configurable, con o sin puertas.
              Ideal para cualquier espacio, desde vestidores hasta habitaciones.
            </p>
            <div className="flex flex-wrap justify-center gap-6 text-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Truck className="h-5 w-5 text-accent" />
                <span>Entrega en toda España</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Shield className="h-5 w-5 text-accent" />
                <span>Garantía 5 años</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Ruler className="h-5 w-5 text-accent" />
                <span>100% personalizable</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Configurador */}
      <section className="py-12 md:py-16">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">

            {/* Panel de configuración */}
            <div className="lg:col-span-2 space-y-8">
              <div className="bg-card rounded-xl border shadow-soft p-6 md:p-8">
                <h2 className="font-serif text-xl md:text-2xl font-semibold mb-6 flex items-center gap-3">
                  <Palette className="h-6 w-6 text-accent" />
                  Configura tu armario
                </h2>

                <Accordion type="multiple" defaultValue={["tipo", "medidas", "puertas", "acabado", "interior"]} className="space-y-4">

                  {/* Tipo de armario */}
                  <AccordionItem value="tipo" className="border rounded-lg px-4">
                    <AccordionTrigger className="text-base font-medium hover:no-underline">
                      1. Tipo de armario
                    </AccordionTrigger>
                    <AccordionContent className="pt-4 pb-6">
                      <RadioGroup value={tipoArmario} onValueChange={setTipoArmario} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {tiposArmario.map((tipo) => (
                          <label
                            key={tipo.id}
                            className={`relative flex flex-col p-4 rounded-lg border-2 cursor-pointer transition-all ${
                              tipoArmario === tipo.id
                                ? "border-primary bg-primary/5"
                                : "border-border hover:border-accent/50"
                            }`}
                          >
                            <RadioGroupItem value={tipo.id} className="sr-only" />
                            <span className="font-medium">{tipo.label}</span>
                            <span className="text-sm text-muted-foreground mt-1">{tipo.description}</span>
                            {tipoArmario === tipo.id && (
                              <Check className="absolute top-3 right-3 h-5 w-5 text-primary" />
                            )}
                          </label>
                        ))}
                      </RadioGroup>
                    </AccordionContent>
                  </AccordionItem>

                  {/* Medidas */}
                  <AccordionItem value="medidas" className="border rounded-lg px-4">
                    <AccordionTrigger className="text-base font-medium hover:no-underline">
                      2. Medidas (cm)
                    </AccordionTrigger>
                    <AccordionContent className="pt-4 pb-6">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="ancho">Ancho</Label>
                          <div className="relative">
                            <Input
                              id="ancho"
                              type="number"
                              min={60}
                              max={600}
                              value={ancho}
                              onChange={(e) => setAncho(Number(e.target.value))}
                              className="pr-10"
                            />
                            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">cm</span>
                          </div>
                          <p className="text-xs text-muted-foreground">Mín. 60cm - Máx. 600cm</p>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="alto">Alto</Label>
                          <div className="relative">
                            <Input
                              id="alto"
                              type="number"
                              min={100}
                              max={300}
                              value={alto}
                              onChange={(e) => setAlto(Number(e.target.value))}
                              className="pr-10"
                            />
                            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">cm</span>
                          </div>
                          <p className="text-xs text-muted-foreground">Mín. 100cm - Máx. 300cm</p>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="profundidad">Profundidad</Label>
                          <div className="relative">
                            <Input
                              id="profundidad"
                              type="number"
                              min={40}
                              max={80}
                              value={profundidad}
                              onChange={(e) => setProfundidad(Number(e.target.value))}
                              className="pr-10"
                            />
                            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">cm</span>
                          </div>
                          <p className="text-xs text-muted-foreground">Mín. 40cm - Máx. 80cm</p>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  {/* Tipo de puertas */}
                  <AccordionItem value="puertas" className="border rounded-lg px-4">
                    <AccordionTrigger className="text-base font-medium hover:no-underline">
                      3. Tipo de puertas
                    </AccordionTrigger>
                    <AccordionContent className="pt-4 pb-6 space-y-6">
                      <RadioGroup value={tipoPuerta} onValueChange={setTipoPuerta} className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                        {tiposPuerta.map((puerta) => (
                          <label
                            key={puerta.id}
                            className={`relative flex flex-col items-center p-4 rounded-lg border-2 cursor-pointer transition-all text-center ${
                              tipoPuerta === puerta.id
                                ? "border-primary bg-primary/5"
                                : "border-border hover:border-accent/50"
                            }`}
                          >
                            <RadioGroupItem value={puerta.id} className="sr-only" />
                            <span className="font-medium text-sm">{puerta.label}</span>
                            {puerta.precio > 0 && (
                              <span className="text-xs text-accent mt-1">+{puerta.precio}€/ud</span>
                            )}
                            {tipoPuerta === puerta.id && (
                              <Check className="absolute top-2 right-2 h-4 w-4 text-primary" />
                            )}
                          </label>
                        ))}
                      </RadioGroup>

                      {tipoPuerta !== "sin-puertas" && (
                        <>
                          <div className="space-y-2">
                            <Label htmlFor="numPuertas">Número de puertas</Label>
                            <Select value={String(numPuertas)} onValueChange={(v) => setNumPuertas(Number(v))}>
                              <SelectTrigger className="w-full sm:w-48">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {[2, 3, 4, 5, 6].map((n) => (
                                  <SelectItem key={n} value={String(n)}>{n} puertas</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-3">
                            <Label>Color de puertas</Label>
                            <div className="flex flex-wrap gap-3">
                              {coloresPuerta.map((color) => (
                                <button
                                  key={color.id}
                                  onClick={() => setColorPuerta(color.id)}
                                  className={`group relative flex flex-col items-center gap-2 p-2 rounded-lg transition-all ${
                                    colorPuerta === color.id ? "ring-2 ring-primary ring-offset-2" : ""
                                  }`}
                                  title={color.label}
                                >
                                  <div
                                    className={`w-10 h-10 rounded-full border-2 transition-transform group-hover:scale-110 ${
                                      color.id === "espejo" ? "bg-gradient-to-br from-gray-200 via-white to-gray-300" : ""
                                    }`}
                                    style={{ backgroundColor: color.id !== "espejo" ? color.hex : undefined }}
                                  />
                                  <span className="text-xs">{color.label}</span>
                                </button>
                              ))}
                            </div>
                          </div>
                        </>
                      )}
                    </AccordionContent>
                  </AccordionItem>

                  {/* Acabado */}
                  <AccordionItem value="acabado" className="border rounded-lg px-4">
                    <AccordionTrigger className="text-base font-medium hover:no-underline">
                      4. Acabado del cuerpo
                    </AccordionTrigger>
                    <AccordionContent className="pt-4 pb-6">
                      <RadioGroup value={acabado} onValueChange={setAcabado} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                        {acabados.map((a) => (
                          <label
                            key={a.id}
                            className={`relative flex items-center justify-between p-4 rounded-lg border-2 cursor-pointer transition-all ${
                              acabado === a.id
                                ? "border-primary bg-primary/5"
                                : "border-border hover:border-accent/50"
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <RadioGroupItem value={a.id} className="sr-only" />
                              <span className="font-medium text-sm">{a.label}</span>
                            </div>
                            {a.precio > 0 && (
                              <span className="text-xs text-accent">+{a.precio}€/m²</span>
                            )}
                            {acabado === a.id && (
                              <Check className="absolute top-2 right-2 h-4 w-4 text-primary" />
                            )}
                          </label>
                        ))}
                      </RadioGroup>
                    </AccordionContent>
                  </AccordionItem>

                  {/* Interior */}
                  <AccordionItem value="interior" className="border rounded-lg px-4">
                    <AccordionTrigger className="text-base font-medium hover:no-underline">
                      5. Configuración interior
                    </AccordionTrigger>
                    <AccordionContent className="pt-4 pb-6">
                      <RadioGroup value={interior} onValueChange={setInterior} className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        {interiores.map((i) => (
                          <label
                            key={i.id}
                            className={`relative flex flex-col p-4 rounded-lg border-2 cursor-pointer transition-all ${
                              interior === i.id
                                ? "border-primary bg-primary/5"
                                : "border-border hover:border-accent/50"
                            }`}
                          >
                            <RadioGroupItem value={i.id} className="sr-only" />
                            <span className="font-medium">{i.label}</span>
                            <span className="text-sm text-muted-foreground mt-1">{i.description}</span>
                            {i.precio > 0 && (
                              <span className="text-sm text-accent mt-2">+{i.precio}€</span>
                            )}
                            {interior === i.id && (
                              <Check className="absolute top-3 right-3 h-5 w-5 text-primary" />
                            )}
                          </label>
                        ))}
                      </RadioGroup>
                    </AccordionContent>
                  </AccordionItem>

                </Accordion>
              </div>
            </div>

            {/* Panel lateral - Resumen y precio */}
            <div className="lg:col-span-1">
              <div className="sticky top-32 space-y-6">

                {/* Precio estimado */}
                <div className="bg-card rounded-xl border shadow-soft p-6">
                  <h3 className="font-serif text-lg font-semibold mb-4">Resumen de tu armario</h3>

                  <div className="space-y-3 text-sm mb-6">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Tipo:</span>
                      <span className="font-medium">{tiposArmario.find(t => t.id === tipoArmario)?.label}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Medidas:</span>
                      <span className="font-medium">{ancho} x {alto} x {profundidad} cm</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Puertas:</span>
                      <span className="font-medium">
                        {tipoPuerta === "sin-puertas" ? "Sin puertas" : `${numPuertas} ${tiposPuerta.find(p => p.id === tipoPuerta)?.label.toLowerCase()}`}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Acabado:</span>
                      <span className="font-medium">{acabados.find(a => a.id === acabado)?.label}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Interior:</span>
                      <span className="font-medium">{interiores.find(i => i.id === interior)?.label}</span>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex items-baseline justify-between mb-2">
                      <span className="text-muted-foreground">Precio estimado:</span>
                    </div>
                    <div className="text-3xl font-serif font-bold text-primary">
                      {precioEstimado.toLocaleString("es-ES")} €
                    </div>
                    <p className="text-xs text-muted-foreground mt-2 flex items-start gap-1">
                      <Info className="h-3 w-3 mt-0.5 flex-shrink-0" />
                      Precio orientativo. El precio final se confirmará tras la medición profesional.
                    </p>
                  </div>

                  <Button asChild size="lg" className="w-full mt-6">
                    <Link to="/contacto">Solicitar Presupuesto</Link>
                  </Button>
                </div>

                {/* Características */}
                <div className="bg-secondary/50 rounded-xl p-6">
                  <h3 className="font-semibold mb-4">Incluido en tu armario</h3>
                  <ul className="space-y-2">
                    {caracteristicas.map((car) => (
                      <li key={car} className="flex items-start gap-2 text-sm">
                        <Check className="h-4 w-4 text-accent flex-shrink-0 mt-0.5" />
                        <span>{car}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Contacto */}
                <div className="bg-primary/5 rounded-xl p-6">
                  <h3 className="font-semibold mb-3">¿Necesitas ayuda?</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Nuestros expertos te ayudarán a diseñar tu armario perfecto.
                  </p>
                  <div className="flex flex-col gap-2">
                    <a
                      href="tel:983625022"
                      className="flex items-center gap-2 text-sm text-foreground hover:text-primary transition-colors"
                    >
                      <Phone className="h-4 w-4" />
                      983 625 022
                    </a>
                    <a
                      href="mailto:cydma@cydma.es"
                      className="flex items-center gap-2 text-sm text-foreground hover:text-primary transition-colors"
                    >
                      <Mail className="h-4 w-4" />
                      cydma@cydma.es
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sección informativa */}
      <section className="py-16 bg-secondary/30">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-serif text-2xl md:text-3xl font-semibold text-center mb-12">
              ¿Por qué elegir un armario a medida?
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mx-auto mb-4">
                  <Ruler className="h-8 w-8 text-accent" />
                </div>
                <h3 className="font-semibold mb-2">Aprovecha cada centímetro</h3>
                <p className="text-sm text-muted-foreground">
                  Diseño personalizado que se adapta perfectamente a tu espacio,
                  sin huecos ni zonas muertas.
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mx-auto mb-4">
                  <Palette className="h-8 w-8 text-accent" />
                </div>
                <h3 className="font-semibold mb-2">Totalmente personalizable</h3>
                <p className="text-sm text-muted-foreground">
                  Elige acabados, colores, tipo de puertas y distribución interior
                  según tus necesidades.
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-8 w-8 text-accent" />
                </div>
                <h3 className="font-semibold mb-2">Calidad garantizada</h3>
                <p className="text-sm text-muted-foreground">
                  Fabricación propia con materiales de primera calidad.
                  5 años de garantía en todos nuestros armarios.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container text-center">
          <h2 className="font-serif text-2xl md:text-3xl font-semibold mb-4">
            ¿Listo para diseñar tu armario perfecto?
          </h2>
          <p className="text-primary-foreground/80 mb-8 max-w-2xl mx-auto">
            Contacta con nosotros para una medición gratuita y recibe un presupuesto
            personalizado sin compromiso.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="secondary">
              <Link to="/contacto">Solicitar Presupuesto Gratuito</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10">
              <a href="tel:983625022">
                <Phone className="h-4 w-4 mr-2" />
                Llamar ahora
              </a>
            </Button>
          </div>
        </div>
      </section>
    </Layout>
  );
}
