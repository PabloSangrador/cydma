import { Link } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import { categories, getProductCountByCategory } from "@/data/catalog";
import { ArrowRight } from "lucide-react";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";

export default function Catalogo() {
  return (
    <Layout>
      {/* Breadcrumb */}
      <div className="bg-secondary/30 border-b">
        <div className="container py-4">
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink asChild>
                  <Link to="/">Inicio</Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbPage>Catálogo</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
        </div>
      </div>

      {/* Header */}
      <section className="py-16 bg-secondary/30">
        <div className="container">
          <h1 className="font-serif text-display-sm md:text-display text-foreground mb-4">
            Catálogo de Productos
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl">
            Explore nuestra amplia gama de productos de carpintería industrial.
            Calidad y diseño para profesionales exigentes.
          </p>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="py-16">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {categories.map((category, index) => (
              <Link
                key={category.id}
                to={`/catalogo/${category.slug}`}
                className="group relative overflow-hidden rounded-lg aspect-[4/3] opacity-0 animate-fade-in-up"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <img
                  src={category.image}
                  alt={category.name}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h2 className="font-serif text-2xl font-semibold text-white mb-2">
                    {category.name}
                  </h2>
                  <p className="text-sm text-white/80 mb-3 line-clamp-2">
                    {category.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-white/60">
                      {getProductCountByCategory(category.id)} productos
                    </span>
                    <span className="flex items-center gap-1 text-white text-sm font-medium opacity-0 translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all">
                      Ver categoría
                      <ArrowRight className="h-4 w-4" />
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Subcategories Preview */}
      <section className="py-16 bg-secondary/30">
        <div className="container">
          <h2 className="font-serif text-display-sm text-foreground mb-8">
            Navegue por Subcategorías
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories
              .filter((c) => c.subcategories && c.subcategories.length > 0)
              .map((category) => (
                <div key={category.id} className="bg-background rounded-lg p-6 shadow-soft">
                  <h3 className="font-serif text-lg font-semibold mb-4">{category.name}</h3>
                  <ul className="space-y-2">
                    {category.subcategories?.slice(0, 5).map((sub) => (
                      <li key={sub.id}>
                        <Link
                          to={`/catalogo/${category.slug}/${sub.slug}`}
                          className="text-sm text-muted-foreground hover:text-primary transition-colors"
                        >
                          {sub.name}
                        </Link>
                      </li>
                    ))}
                    {category.subcategories && category.subcategories.length > 5 && (
                      <li>
                        <Link
                          to={`/catalogo/${category.slug}`}
                          className="text-sm text-accent font-medium hover:underline"
                        >
                          Ver todas →
                        </Link>
                      </li>
                    )}
                  </ul>
                </div>
              ))}
          </div>
        </div>
      </section>
    </Layout>
  );
}
