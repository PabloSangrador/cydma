import { Link, useParams } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import {
  categories,
  getCategoryBySlug,
  getProductsByCategory,
  getProductsBySubcategory,
} from "@/data/catalog";
import { ArrowRight } from "lucide-react";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Button } from "@/components/ui/button";

export default function CatalogoCategoria() {
  const { categoria, subcategoria } = useParams<{
    categoria: string;
    subcategoria?: string;
  }>();

  const category = getCategoryBySlug(categoria || "");
  const subcategoryData = category?.subcategories?.find(
    (s) => s.slug === subcategoria
  );

  if (!category) {
    return (
      <Layout>
        <div className="container py-24 text-center">
          <h1 className="font-serif text-2xl mb-4">Categoría no encontrada</h1>
          <Button asChild>
            <Link to="/catalogo">Volver al catálogo</Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const products = subcategoria
    ? getProductsBySubcategory(category.id, subcategoryData?.id || "")
    : getProductsByCategory(category.id);

  return (
    <Layout>
      {/* Breadcrumb */}
      <div className="bg-secondary/30 border-b">
        <div className="container py-4">
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink asChild>
                  <Link to="/">Inicio</Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink asChild>
                  <Link to="/catalogo">Catálogo</Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              {subcategoria ? (
                <>
                  <BreadcrumbItem>
                    <BreadcrumbLink asChild>
                      <Link to={`/catalogo/${categoria}`}>{category.name}</Link>
                    </BreadcrumbLink>
                  </BreadcrumbItem>
                  <BreadcrumbSeparator />
                  <BreadcrumbItem>
                    <BreadcrumbPage>{subcategoryData?.name}</BreadcrumbPage>
                  </BreadcrumbItem>
                </>
              ) : (
                <BreadcrumbItem>
                  <BreadcrumbPage>{category.name}</BreadcrumbPage>
                </BreadcrumbItem>
              )}
            </BreadcrumbList>
          </Breadcrumb>
        </div>
      </div>

      {/* Header */}
      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h1 className="font-serif text-display-sm md:text-display text-foreground mb-2">
            {subcategoryData?.name || category.name}
          </h1>
          <p className="text-muted-foreground">
            {subcategoryData?.description || category.description}
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="py-12">
        <div className="container">
          <div className="flex flex-col lg:flex-row gap-12">
            {/* Sidebar - Subcategories */}
            <aside className="lg:w-64 flex-shrink-0">
              <div className="sticky top-32">
                <h3 className="font-serif text-lg font-semibold mb-4">
                  {subcategoria ? "Subcategorías" : "Filtrar por"}
                </h3>
                {category.subcategories && category.subcategories.length > 0 ? (
                  <ul className="space-y-2">
                    <li>
                      <Link
                        to={`/catalogo/${category.slug}`}
                        className={`block px-3 py-2 rounded-md text-sm transition-colors ${
                          !subcategoria
                            ? "bg-primary text-primary-foreground"
                            : "hover:bg-secondary"
                        }`}
                      >
                        Todas ({getProductsByCategory(category.id).length})
                      </Link>
                    </li>
                    {category.subcategories.map((sub) => (
                      <li key={sub.id}>
                        <Link
                          to={`/catalogo/${category.slug}/${sub.slug}`}
                          className={`block px-3 py-2 rounded-md text-sm transition-colors ${
                            subcategoria === sub.slug
                              ? "bg-primary text-primary-foreground"
                              : "hover:bg-secondary"
                          }`}
                        >
                          {sub.name}
                        </Link>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    No hay subcategorías
                  </p>
                )}

                {/* Other Categories */}
                <div className="mt-8 pt-8 border-t">
                  <h4 className="font-semibold text-sm mb-3 text-muted-foreground uppercase tracking-wider">
                    Otras categorías
                  </h4>
                  <ul className="space-y-1">
                    {categories
                      .filter((c) => c.id !== category.id)
                      .map((c) => (
                        <li key={c.id}>
                          <Link
                            to={`/catalogo/${c.slug}`}
                            className="text-sm text-muted-foreground hover:text-primary transition-colors"
                          >
                            {c.name}
                          </Link>
                        </li>
                      ))}
                  </ul>
                </div>
              </div>
            </aside>

            {/* Products Grid */}
            <div className="flex-1">
              {products.length > 0 ? (
                <>
                  <div className="flex items-center justify-between mb-6">
                    <p className="text-sm text-muted-foreground">
                      {products.length} producto{products.length !== 1 ? "s" : ""}
                    </p>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {products.map((product, index) => (
                      <Link
                        key={product.id}
                        to={`/producto/${product.id}`}
                        className="group bg-card rounded-lg overflow-hidden border shadow-soft hover:shadow-soft-lg transition-shadow opacity-0 animate-fade-in-up"
                        style={{ animationDelay: `${index * 0.05}s` }}
                      >
                        <div className="aspect-[4/5] overflow-hidden bg-secondary/30">
                          <img
                            src={product.images[0]}
                            alt={product.name}
                            className="w-full h-full object-contain transition-transform duration-500 group-hover:scale-105"
                          />
                        </div>
                        <div className="p-4">
                          <p className="text-xs text-accent font-medium mb-1">
                            {product.code}
                          </p>
                          <h3 className="font-serif text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
                            {product.name}
                          </h3>
                          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                            {product.description}
                          </p>
                          <span className="inline-flex items-center gap-1 text-sm text-primary font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                            Ver detalles
                            <ArrowRight className="h-3 w-3" />
                          </span>
                        </div>
                      </Link>
                    ))}
                  </div>
                </>
              ) : (
                <div className="text-center py-16">
                  <p className="text-muted-foreground mb-4">
                    No hay productos en esta categoría.
                  </p>
                  <Button asChild variant="outline">
                    <Link to="/catalogo">Ver todo el catálogo</Link>
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
