import Layout from "@/components/layout/Layout";
import HeroSection from "@/components/home/HeroSection";
import ValuesSection from "@/components/home/ValuesSection";
import CategoriesSection from "@/components/home/CategoriesSection";
import BusinessLinesSection from "@/components/home/BusinessLinesSection";
import CTASection from "@/components/home/CTASection";

export default function Index() {
  return (
    <Layout>
      <HeroSection />
      <ValuesSection />
      <CategoriesSection />
      <BusinessLinesSection />
      <CTASection />
    </Layout>
  );
}
