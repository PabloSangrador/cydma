import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Checkbox } from "@/components/ui/checkbox";
import { Check, Phone, Mail, Truck, Shield, ArrowRight, ArrowLeft, Info, DoorOpen } from "lucide-react";
import { categories, products, getProductsBySubcategory, type Product } from "@/data/catalog";

// Obtener la categoría de puertas y sus subcategorías
const puertasCategory = categories.find(c => c.id === "puertas");
const subcategoriasPuertas = puertasCategory?.subcategories || [];

// Configuración de opciones adicionales
const medidasHueco = [
  { id: "2030x625", label: "2030 x 625 mm", precio: 0 },
  { id: "2030x725", label: "2030 x 725 mm", precio: 0 },
  { id: "2030x825", label: "2030 x 825 mm", precio: 0 },
  { id: "2030x925", label: "2030 x 925 mm", precio: 15 },
  { id: "2100x825", label: "2100 x 825 mm", precio: 25 },
  { id: "2100x925", label: "2100 x 925 mm", precio: 35 },
  { id: "medida-especial", label: "Medida especial", precio: 80 },
];

const espesoresTabique = [
  { id: "7-9", label: "7-9 cm", precio: 0 },
  { id: "9-11", label: "9-11 cm", precio: 5 },
  { id: "11-13", label: "11-13 cm", precio: 10 },
  { id: "13-15", label: "13-15 cm", precio: 15 },
  { id: "15-18", label: "15-18 cm", precio: 25 },
];

const direccionesApertura = [
  { id: "derecha-empujando", label: "Derecha empujando" },
  { id: "izquierda-empujando", label: "Izquierda empujando" },
];

const coloresHerraje = [
  { id: "inox", label: "Inox / Cromado", precio: 0 },
  { id: "negro-mate", label: "Negro Mate", precio: 15 },
  { id: "dorado", label: "Dorado", precio: 18 },
  { id: "bronce", label: "Bronce", precio: 18 },
];

const tiposCerradura = [
  { id: "picaporte", label: "Picaporte estándar", precio: 0 },
  { id: "magnetica", label: "Cierre magnético", precio: 25 },
  { id: "condena-wc", label: "Condena WC (baño)", precio: 12 },
  { id: "llave", label: "Con llave", precio: 35 },
];

const complementos = [
  { id: "molduras-70", label: "Molduras 70x10 mm", precio: 18 },
  { id: "molduras-90", label: "Molduras 90x10 mm", precio: 24 },
  { id: "burlete", label: "Burlete de goma", precio: 8 },
  { id: "bisagras-ocultas", label: "Bisagras ocultas", precio: 85 },
  { id: "espuma", label: "Espuma poliuretano", precio: 6 },
  { id: "silicona", label: "Silicona blanca", precio: 5 },
];

// Precios base por tipo de puerta
const preciosBase: Record<string, number> = {
  "lisas": 159,
  "fresadas": 189,
  "lacadas": 219,
  "clasicas": 199,
  "vinilo-2d": 149,
  "vinilo-3d": 169,
};

export default function PuertasMedida() {
  // Estado del configurador - Categoría y Modelo
  const [categoriaSeleccionada, setCategoriaSeleccionada] = useState(subcategoriasPuertas[0]?.id || "");
  const [modeloSeleccionado, setModeloSeleccionado] = useState("");

  // Resto de opciones
  const [medidaHueco, setMedidaHueco] = useState("2030x825");
  const [espesorTabique, setEspesorTabique] = useState("7-9");
  const [direccionApertura, setDireccionApertura] = useState("derecha-empujando");
  const [colorHerraje, setColorHerraje] = useState("inox");
  const [tipoCerradura, setTipoCerradura] = useState("picaporte");
  const [complementosSeleccionados, setComplementosSeleccionados] = useState<string[]>([]);

  // Obtener modelos de la categoría seleccionada
  const modelosDisponibles = useMemo(() => {
    if (!categoriaSeleccionada) return [];
    return getProductsBySubcategory("puertas", categoriaSeleccionada);
  }, [categoriaSeleccionada]);

  // Auto-seleccionar primer modelo cuando cambia la categoría
  useMemo(() => {
    if (modelosDisponibles.length > 0 && !modelosDisponibles.find(m => m.id === modeloSeleccionado)) {
      setModeloSeleccionado(modelosDisponibles[0].id);
    }
  }, [modelosDisponibles, modeloSeleccionado]);

  // Obtener el producto seleccionado
  const productoSeleccionado = useMemo(() => {
    return products.find(p => p.id === modeloSeleccionado);
  }, [modeloSeleccionado]);

  // Toggle complementos
  const toggleComplemento = (id: string) => {
    setComplementosSeleccionados(prev =>
      prev.includes(id) ? prev.filter(c => c !== id) : [...prev, id]
    );
  };

  // Cálculo del precio estimado
  const precioEstimado = useMemo(() => {
    let precio = preciosBase[categoriaSeleccionada] || 189;

    // Medida
    const medidaSeleccionadaObj = medidasHueco.find(m => m.id === medidaHueco);
    precio += medidaSeleccionadaObj?.precio || 0;

    // Espesor tabique
    const espesorSeleccionado = espesoresTabique.find(e => e.id === espesorTabique);
    precio += espesorSeleccionado?.precio || 0;

    // Color herraje
    const herrajeSeleccionado = coloresHerraje.find(h => h.id === colorHerraje);
    precio += herrajeSeleccionado?.precio || 0;

    // Tipo cerradura
    const cerraduraSeleccionada = tiposCerradura.find(c => c.id === tipoCerradura);
    precio += cerraduraSeleccionada?.precio || 0;

    // Complementos
    complementosSeleccionados.forEach(compId => {
      const comp = complementos.find(c => c.id === compId);
      precio += comp?.precio || 0;
    });

    return precio;
  }, [categoriaSeleccionada, medidaHueco, espesorTabique, colorHerraje, tipoCerradura, complementosSeleccionados]);

  // Obtener nombre de categoría
  const categoriaNombre = subcategoriasPuertas.find(s => s.id === categoriaSeleccionada)?.name || "";

  const caracteristicas = [
    "Fabricación 100% a medida",
    "Materiales de primera calidad",
    "Tablero de alta densidad",
    "Herrajes incluidos",
    "Cerco y tapetas incluidos",
    "Garantía de 3 años",
    "Entrega en 10-15 días",
  ];

  return (
    <Layout>
      {/* Breadcrumb */}
      <div className="bg-secondary/30 border-b">
        <div className="container py-4">
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink asChild>
                  <Link to="/">Inicio</Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink asChild>
                  <Link to="/catalogo">Catálogo</Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbPage>Puertas a Medida</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
        </div>
      </div>

      {/* Contenido principal */}
      <section className="py-8 md:py-12">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">

            {/* Galería de imágenes */}
            <div className="lg:col-span-5">
              <div className="sticky top-32 space-y-4">
                {/* Imagen principal del modelo seleccionado */}
                <div className="aspect-[3/4] rounded-xl overflow-hidden bg-secondary/30 shadow-soft relative">
                  {productoSeleccionado ? (
                    <img
                      src={productoSeleccionado.images[0]}
                      alt={productoSeleccionado.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                      <DoorOpen className="h-16 w-16 opacity-30" />
                    </div>
                  )}
                  {/* Badge con el modelo */}
                  {productoSeleccionado && (
                    <div className="absolute top-4 left-4 bg-primary text-primary-foreground px-3 py-1.5 rounded-lg text-sm font-medium shadow-lg">
                      {productoSeleccionado.name}
                    </div>
                  )}
                </div>

                {/* Info del modelo seleccionado */}
                {productoSeleccionado && (
                  <div className="bg-card rounded-xl border p-4">
                    <h3 className="font-semibold text-lg mb-1">{productoSeleccionado.name}</h3>
                    <p className="text-sm text-muted-foreground mb-3">{productoSeleccionado.description}</p>
                    {productoSeleccionado.features && (
                      <div className="flex flex-wrap gap-2">
                        {productoSeleccionado.features.slice(0, 3).map((feature) => (
                          <span key={feature} className="text-xs bg-secondary px-2 py-1 rounded">
                            {feature}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Características en móvil */}
                <div className="lg:hidden bg-secondary/50 rounded-xl p-5">
                  <h3 className="font-semibold mb-3">Incluido</h3>
                  <ul className="space-y-2">
                    {caracteristicas.slice(0, 4).map((car) => (
                      <li key={car} className="flex items-start gap-2 text-sm">
                        <Check className="h-4 w-4 text-accent flex-shrink-0 mt-0.5" />
                        <span>{car}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Configurador */}
            <div className="lg:col-span-7 space-y-6">
              {/* Título y descripción */}
              <div>
                <div className="flex items-center gap-2 text-accent text-sm font-medium mb-2">
                  <DoorOpen className="h-4 w-4" />
                  <span>Configurador de puertas</span>
                </div>
                <h1 className="font-serif text-2xl md:text-display-sm text-foreground mb-3">
                  Puerta de Interior a Medida
                </h1>
                <p className="text-muted-foreground">
                  Elige el modelo de puerta y configura todos los detalles. Block completo con cerco, tapetas y herrajes incluidos.
                </p>
              </div>

              {/* Panel de precio (móvil) */}
              <div className="lg:hidden bg-primary/5 rounded-xl p-5 border border-primary/10">
                <div className="flex items-baseline justify-between">
                  <span className="text-sm text-muted-foreground">Precio estimado:</span>
                  <div className="text-2xl font-serif font-bold text-primary">
                    {precioEstimado.toLocaleString("es-ES")} €
                  </div>
                </div>
              </div>

              {/* Configurador con acordeón */}
              <div className="bg-card rounded-xl border shadow-soft">
                <Accordion type="multiple" defaultValue={["categoria", "modelo", "medidas", "apertura", "herrajes", "complementos"]} className="divide-y">

                  {/* 1. Categoría de puerta */}
                  <AccordionItem value="categoria" className="border-0 px-5">
                    <AccordionTrigger className="text-base font-medium hover:no-underline py-4">
                      1. Tipo de puerta
                    </AccordionTrigger>
                    <AccordionContent className="pb-5">
                      <RadioGroup
                        value={categoriaSeleccionada}
                        onValueChange={(value) => {
                          setCategoriaSeleccionada(value);
                          setModeloSeleccionado(""); // Reset modelo al cambiar categoría
                        }}
                        className="grid grid-cols-2 sm:grid-cols-3 gap-3"
                      >
                        {subcategoriasPuertas.map((subcategoria) => (
                          <label
                            key={subcategoria.id}
                            className={`relative flex flex-col p-4 rounded-lg border-2 cursor-pointer transition-all ${
                              categoriaSeleccionada === subcategoria.id
                                ? "border-primary bg-primary/5"
                                : "border-border hover:border-accent/50"
                            }`}
                          >
                            <RadioGroupItem value={subcategoria.id} className="sr-only" />
                            <span className="font-medium text-sm">{subcategoria.name}</span>
                            {subcategoria.description && (
                              <span className="text-xs text-muted-foreground mt-1 line-clamp-2">
                                {subcategoria.description}
                              </span>
                            )}
                            <span className="text-xs text-accent mt-2">
                              Desde {preciosBase[subcategoria.id] || 189}€
                            </span>
                            {categoriaSeleccionada === subcategoria.id && (
                              <Check className="absolute top-3 right-3 h-4 w-4 text-primary" />
                            )}
                          </label>
                        ))}
                      </RadioGroup>
                    </AccordionContent>
                  </AccordionItem>

                  {/* 2. Modelo específico */}
                  <AccordionItem value="modelo" className="border-0 px-5">
                    <AccordionTrigger className="text-base font-medium hover:no-underline py-4">
                      2. Modelo {categoriaNombre && `(${categoriaNombre})`}
                    </AccordionTrigger>
                    <AccordionContent className="pb-5">
                      {modelosDisponibles.length > 0 ? (
                        <RadioGroup
                          value={modeloSeleccionado}
                          onValueChange={setModeloSeleccionado}
                          className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3"
                        >
                          {modelosDisponibles.map((modelo) => (
                            <label
                              key={modelo.id}
                              className={`relative flex flex-col rounded-lg border-2 cursor-pointer transition-all overflow-hidden ${
                                modeloSeleccionado === modelo.id
                                  ? "border-primary ring-2 ring-primary/20"
                                  : "border-border hover:border-accent/50"
                              }`}
                            >
                              <RadioGroupItem value={modelo.id} className="sr-only" />
                              {/* Miniatura */}
                              <div className="aspect-[3/4] bg-secondary/30 overflow-hidden">
                                <img
                                  src={modelo.images[0]}
                                  alt={modelo.name}
                                  className="w-full h-full object-cover transition-transform hover:scale-105"
                                />
                              </div>
                              {/* Info */}
                              <div className="p-2 bg-card">
                                <span className="font-medium text-sm block truncate">{modelo.name}</span>
                                <span className="text-xs text-muted-foreground">{modelo.code}</span>
                              </div>
                              {modeloSeleccionado === modelo.id && (
                                <div className="absolute top-2 right-2 bg-primary text-primary-foreground rounded-full p-1">
                                  <Check className="h-3 w-3" />
                                </div>
                              )}
                            </label>
                          ))}
                        </RadioGroup>
                      ) : (
                        <p className="text-sm text-muted-foreground">
                          Selecciona primero un tipo de puerta
                        </p>
                      )}
                    </AccordionContent>
                  </AccordionItem>

                  {/* 3. Medidas */}
                  <AccordionItem value="medidas" className="border-0 px-5">
                    <AccordionTrigger className="text-base font-medium hover:no-underline py-4">
                      3. Medidas
                    </AccordionTrigger>
                    <AccordionContent className="pb-5 space-y-5">
                      <div className="space-y-2">
                        <Label>Medida del hueco</Label>
                        <Select value={medidaHueco} onValueChange={setMedidaHueco}>
                          <SelectTrigger className="w-full">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {medidasHueco.map((medida) => (
                              <SelectItem key={medida.id} value={medida.id}>
                                {medida.label}
                                {medida.precio > 0 && ` (+${medida.precio}€)`}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <p className="text-xs text-muted-foreground">
                          Mide el hueco de la pared (alto x ancho)
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label>Espesor del tabique</Label>
                        <Select value={espesorTabique} onValueChange={setEspesorTabique}>
                          <SelectTrigger className="w-full">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {espesoresTabique.map((espesor) => (
                              <SelectItem key={espesor.id} value={espesor.id}>
                                {espesor.label}
                                {espesor.precio > 0 && ` (+${espesor.precio}€)`}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  {/* 4. Dirección de apertura */}
                  <AccordionItem value="apertura" className="border-0 px-5">
                    <AccordionTrigger className="text-base font-medium hover:no-underline py-4">
                      4. Dirección de apertura
                    </AccordionTrigger>
                    <AccordionContent className="pb-5">
                      <RadioGroup value={direccionApertura} onValueChange={setDireccionApertura} className="grid grid-cols-2 gap-4">
                        {direccionesApertura.map((dir) => (
                          <label
                            key={dir.id}
                            className={`relative flex flex-col items-center p-5 rounded-lg border-2 cursor-pointer transition-all ${
                              direccionApertura === dir.id
                                ? "border-primary bg-primary/5"
                                : "border-border hover:border-accent/50"
                            }`}
                          >
                            <RadioGroupItem value={dir.id} className="sr-only" />
                            <div className="w-16 h-24 border-2 border-current rounded relative mb-3">
                              {dir.id === "derecha-empujando" ? (
                                <ArrowRight className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-6 w-6" />
                              ) : (
                                <ArrowLeft className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-6 w-6" />
                              )}
                              <div className={`absolute top-2 ${dir.id === "derecha-empujando" ? "right-1" : "left-1"} w-1.5 h-1.5 rounded-full bg-current`} />
                            </div>
                            <span className="font-medium text-sm text-center">{dir.label}</span>
                            {direccionApertura === dir.id && (
                              <Check className="absolute top-2 right-2 h-4 w-4 text-primary" />
                            )}
                          </label>
                        ))}
                      </RadioGroup>
                    </AccordionContent>
                  </AccordionItem>

                  {/* 5. Herrajes y cerradura */}
                  <AccordionItem value="herrajes" className="border-0 px-5">
                    <AccordionTrigger className="text-base font-medium hover:no-underline py-4">
                      5. Herrajes y cerradura
                    </AccordionTrigger>
                    <AccordionContent className="pb-5 space-y-5">
                      <div className="space-y-3">
                        <Label>Color de herrajes</Label>
                        <RadioGroup value={colorHerraje} onValueChange={setColorHerraje} className="grid grid-cols-2 gap-3">
                          {coloresHerraje.map((herraje) => (
                            <label
                              key={herraje.id}
                              className={`relative flex items-center justify-between p-3 rounded-lg border-2 cursor-pointer transition-all ${
                                colorHerraje === herraje.id
                                  ? "border-primary bg-primary/5"
                                  : "border-border hover:border-accent/50"
                              }`}
                            >
                              <div className="flex items-center gap-2">
                                <RadioGroupItem value={herraje.id} className="sr-only" />
                                <span className="text-sm">{herraje.label}</span>
                              </div>
                              {herraje.precio > 0 && (
                                <span className="text-xs text-accent">+{herraje.precio}€</span>
                              )}
                              {colorHerraje === herraje.id && (
                                <Check className="h-4 w-4 text-primary ml-2" />
                              )}
                            </label>
                          ))}
                        </RadioGroup>
                      </div>

                      <div className="space-y-3">
                        <Label>Tipo de cerradura</Label>
                        <RadioGroup value={tipoCerradura} onValueChange={setTipoCerradura} className="grid grid-cols-2 gap-3">
                          {tiposCerradura.map((cerradura) => (
                            <label
                              key={cerradura.id}
                              className={`relative flex items-center justify-between p-3 rounded-lg border-2 cursor-pointer transition-all ${
                                tipoCerradura === cerradura.id
                                  ? "border-primary bg-primary/5"
                                  : "border-border hover:border-accent/50"
                              }`}
                            >
                              <div className="flex items-center gap-2">
                                <RadioGroupItem value={cerradura.id} className="sr-only" />
                                <span className="text-sm">{cerradura.label}</span>
                              </div>
                              {cerradura.precio > 0 && (
                                <span className="text-xs text-accent">+{cerradura.precio}€</span>
                              )}
                              {tipoCerradura === cerradura.id && (
                                <Check className="h-4 w-4 text-primary ml-2" />
                              )}
                            </label>
                          ))}
                        </RadioGroup>
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  {/* 6. Complementos */}
                  <AccordionItem value="complementos" className="border-0 px-5">
                    <AccordionTrigger className="text-base font-medium hover:no-underline py-4">
                      6. Complementos (opcional)
                    </AccordionTrigger>
                    <AccordionContent className="pb-5">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {complementos.map((comp) => (
                          <label
                            key={comp.id}
                            className={`flex items-center justify-between p-3 rounded-lg border-2 cursor-pointer transition-all ${
                              complementosSeleccionados.includes(comp.id)
                                ? "border-primary bg-primary/5"
                                : "border-border hover:border-accent/50"
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <Checkbox
                                checked={complementosSeleccionados.includes(comp.id)}
                                onCheckedChange={() => toggleComplemento(comp.id)}
                              />
                              <span className="text-sm">{comp.label}</span>
                            </div>
                            <span className="text-xs text-accent">+{comp.precio}€</span>
                          </label>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                </Accordion>
              </div>

              {/* Panel de precio y CTA (desktop) */}
              <div className="hidden lg:block bg-card rounded-xl border shadow-soft p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Precio estimado</p>
                    <div className="text-3xl font-serif font-bold text-primary">
                      {precioEstimado.toLocaleString("es-ES")} €
                    </div>
                  </div>
                  <div className="text-right text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Truck className="h-4 w-4" />
                      <span>Envío en 10-15 días</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground mt-1">
                      <Shield className="h-4 w-4" />
                      <span>Garantía 3 años</span>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-muted-foreground mb-4 flex items-start gap-1">
                  <Info className="h-3 w-3 mt-0.5 flex-shrink-0" />
                  Precio orientativo. IVA incluido. El precio final se confirmará en el presupuesto.
                </p>

                <Button asChild size="lg" className="w-full">
                  <Link to="/contacto">Solicitar Presupuesto</Link>
                </Button>

                {/* Resumen de configuración */}
                <div className="mt-6 pt-6 border-t space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tipo:</span>
                    <span>{categoriaNombre}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Modelo:</span>
                    <span>{productoSeleccionado?.name || "-"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Medida:</span>
                    <span>{medidasHueco.find(m => m.id === medidaHueco)?.label}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Apertura:</span>
                    <span>{direccionesApertura.find(d => d.id === direccionApertura)?.label}</span>
                  </div>
                </div>
              </div>

              {/* CTA móvil fijo */}
              <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-card border-t p-4 z-40">
                <div className="container flex items-center justify-between gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Precio estimado</p>
                    <div className="text-xl font-serif font-bold text-primary">
                      {precioEstimado.toLocaleString("es-ES")} €
                    </div>
                  </div>
                  <Button asChild size="lg">
                    <Link to="/contacto">Solicitar Presupuesto</Link>
                  </Button>
                </div>
              </div>

              {/* Espacio para el CTA fijo en móvil */}
              <div className="lg:hidden h-20" />
            </div>
          </div>
        </div>
      </section>

      {/* Características incluidas */}
      <section className="py-12 bg-secondary/30">
        <div className="container">
          <h2 className="font-serif text-xl md:text-2xl font-semibold text-center mb-8">
            Incluido en tu puerta block
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
            {[
              { label: "Hoja de puerta", desc: "A medida y acabada" },
              { label: "Cerco completo", desc: "Del mismo acabado" },
              { label: "Tapetas", desc: "Juego completo" },
              { label: "Herrajes", desc: "Pernios y manilla" },
            ].map((item) => (
              <div key={item.label} className="bg-card rounded-lg p-4 text-center shadow-soft">
                <Check className="h-6 w-6 text-accent mx-auto mb-2" />
                <p className="font-medium text-sm">{item.label}</p>
                <p className="text-xs text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contacto */}
      <section className="py-12 bg-primary text-primary-foreground">
        <div className="container text-center">
          <h2 className="font-serif text-xl md:text-2xl font-semibold mb-4">
            ¿Necesitas ayuda con tu configuración?
          </h2>
          <p className="text-primary-foreground/80 mb-6 max-w-xl mx-auto">
            Nuestro equipo te asesorará para elegir la puerta perfecta para tu espacio.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="secondary">
              <Link to="/contacto">Contactar</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10">
              <a href="tel:983625022">
                <Phone className="h-4 w-4 mr-2" />
                983 625 022
              </a>
            </Button>
          </div>
        </div>
      </section>
    </Layout>
  );
}
